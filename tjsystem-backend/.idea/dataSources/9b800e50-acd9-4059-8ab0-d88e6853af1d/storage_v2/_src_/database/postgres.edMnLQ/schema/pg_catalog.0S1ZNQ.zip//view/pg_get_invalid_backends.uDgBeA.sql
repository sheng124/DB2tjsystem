create view pg_get_invalid_backends(pid, node_name, dbname, backend_start, query) as
SELECT c.pid, c.node_name, s.datname AS dbname, s.backend_start, s.query
FROM pg_pool_validate(false, ' '::cstring) c(pid, node_name)
         LEFT JOIN pg_stat_activity s ON c.pid = s.sessionid;

alter table pg_get_invalid_backends
    owner to omm;

