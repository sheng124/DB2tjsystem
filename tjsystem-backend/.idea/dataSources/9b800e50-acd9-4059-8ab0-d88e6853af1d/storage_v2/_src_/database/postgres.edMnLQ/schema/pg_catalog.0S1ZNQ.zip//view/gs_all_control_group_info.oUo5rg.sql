create view gs_all_control_group_info (name, type, gid, classgid, class, workload, shares, limits, wdlevel, cpucores) as
SELECT DISTINCT *
FROM gs_all_control_group_info() gs_all_control_group_info(name, type, gid, classgid, class, workload, shares, limits,
                                                           wdlevel, cpucores);

alter table gs_all_control_group_info
    owner to omm;

