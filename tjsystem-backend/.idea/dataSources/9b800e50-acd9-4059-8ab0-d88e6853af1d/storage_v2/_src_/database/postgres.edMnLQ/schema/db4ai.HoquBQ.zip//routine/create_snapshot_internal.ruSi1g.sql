create function create_snapshot_internal(s_id bigint, i_schema name, i_name name, i_commands text[], i_comment text, i_owner name) returns void
    security definer
    SET search_path = pg_catalog, pg_temp
    language plpgsql
as
$$
DECLARE
    e_stack_act TEXT;     -- current stack for validation
    dist_cmd TEXT;        -- DISTRIBUTE BY translation for backing table
    row_count BIGINT;     -- number of rows in this snapshot
BEGIN

    BEGIN
        RAISE EXCEPTION 'SECURITY_STACK_CHECK';
    EXCEPTION WHEN OTHERS THEN
        GET STACKED DIAGNOSTICS e_stack_act = PG_EXCEPTION_CONTEXT;

        IF CURRENT_SCHEMA = 'db4ai' THEN
            e_stack_act := pg_catalog.replace(e_stack_act, 'ion cre', 'ion db4ai.cre');
        END IF;
        
        IF e_stack_act NOT LIKE E'referenced column: create_snapshot_internal\n'
            'SQL statement "SELECT db4ai.create_snapshot_internal(s_id, i_schema, i_name, i_commands, i_comment, CURRENT_USER)"\n'
            'PL/pgSQL function db4ai.create_snapshot(name,name,text[],name,text) line 279 at PERFORM%'
        THEN
            RAISE EXCEPTION 'direct call to db4ai.create_snapshot_internal(bigint,name,name,text[],text,name) is not allowed'
            USING HINT = 'call public interface db4ai.create_snapshot instead';
        END IF;
    END;

    IF pg_catalog.length(i_commands[3]) > 0 THEN
        <<translate_dist_by_hash>>
        DECLARE
            pattern TEXT;             -- current user column name
            mapping NAME[];           -- mapping user column names to internal backing columns

            quoted BOOLEAN := FALSE;  -- inside quoted identifier
            cur_ch VARCHAR;           -- current character in tokenizer
            idx INTEGER := 0;         -- loop counter, cannot use FOR .. iterator
            tokens TEXT;              -- user's column name list in DISTRIBUTE BY HASH()
        BEGIN

            -- extract mapping from projection list for view definition
            mapping := array(SELECT pg_catalog.unnest(ARRAY[ m[1], coalesce(m[2], replace(m[3],'""','"'))]) FROM pg_catalog.regexp_matches(
                i_commands[5], 't[0-9]+\.(f[0-9]+) AS (?:([^\s",]+)|"((?:[^"]*"")*[^"]*)")', 'g') m);

            -- extract field list from DISTRIBUTE BY clause
            tokens :=(pg_catalog.regexp_matches(i_commands[3], '^\s*DISTRIBUTE\s+BY\s+HASH\s*\((.*)\)\s*$', 'i'))[1];
            IF tokens IS NULL OR tokens SIMILAR TO '\s*' THEN
                tokens := (pg_catalog.regexp_matches(i_commands[3], '^\s*DISTRIBUTE\s+BY\s+REPLICATION\s*$', 'i'))[1];
                IF tokens IS NULL OR tokens SIMILAR TO '\s*' THEN
                    RAISE EXCEPTION 'cannot match DISTRIBUTE BY clause'
                    USING HINT = 'currently only DISTRIBUTE BY REPLICATION and DISTRIBUTE BY HASH(column_name [, ...]) supported';
                END IF;
                -- no translation required, bail out
                dist_cmd := ' ' || i_commands[3];
                EXIT translate_dist_by_hash;
            END IF;
            tokens := tokens || ' ';

            -- prepare the translated command
            dist_cmd = ' DISTRIBUTE BY HASH(';

-- BEGIN tokenizer code for testing

            pattern := '';

            LOOP
                idx := idx + 1;
                cur_ch := pg_catalog.substr(tokens, idx, 1);
                EXIT WHEN cur_ch IS NULL OR cur_ch = '';

                CASE cur_ch
                WHEN '"' THEN
                    IF quoted AND pg_catalog.substr(tokens, idx + 1, 1) = '"' THEN
                        pattern := pattern || '"';
                        idx := idx + 1;
                    ELSE
                        quoted := NOT quoted;
                    END IF;
                    IF quoted THEN
                        CONTINUE;
                    END IF;
                WHEN ',' THEN
                    IF quoted THEN
                        pattern := pattern || cur_ch::TEXT;
                        CONTINUE;
                    ELSIF pattern IS NULL OR pg_catalog.length(pattern) = 0 THEN
                        pattern := ',';
                    ELSE
                        idx := idx - 1; -- reset on comma for next loop
                    END IF;
                WHEN ' ', E'\n', E'\t' THEN
                    IF quoted THEN
                        pattern := pattern || cur_ch::TEXT;
                        CONTINUE;
                    ELSIF pattern IS NULL OR pg_catalog.length(pattern) = 0 THEN
                        CONTINUE;
                    END IF;
                ELSE
                    pattern := pattern || CASE WHEN quoted THEN cur_ch::TEXT ELSE pg_catalog.lower(cur_ch)::TEXT END;
                    CONTINUE;
                END CASE;

-- END tokenizer code for testing

                -- attempt to map the pattern
                FOR idx IN 2 .. pg_catalog.array_length(mapping, 1) BY 2 LOOP
                    IF pattern = mapping[idx] THEN
                        -- apply the mapping
                        dist_cmd := dist_cmd || mapping[idx-1] || ',';
                        pattern := NULL;
                        EXIT;
                    END IF;
                END LOOP;

                -- check if pattern was mapped
                IF pattern IS NOT NULL THEN
                    RAISE EXCEPTION 'unable to map field "%" to backing table', pattern;
                END IF;

            END LOOP;

            IF quoted THEN
                RAISE EXCEPTION 'unterminated quoted identifier ''%'' at or near: ''%''',
                    pg_catalog.substr(pattern, 1, pg_catalog.char_length(pattern)-1), i_commands[3];
            END IF;

            dist_cmd := pg_catalog.rtrim(dist_cmd, ',') || ')';
         END;
    END IF;

    dist_cmd := ''; -- we silently drop DISTRIBUTE_BY
    EXECUTE 'CREATE TABLE db4ai.t' || s_id::TEXT || ' WITH (orientation = column, compression = low)' || dist_cmd
        || ' AS SELECT ' || i_commands[4] || ' FROM _db4ai_tmp_x' || s_id::TEXT;
    EXECUTE 'COMMENT ON TABLE db4ai.t' || s_id::TEXT || ' IS ''snapshot backing table, root is ' || pg_catalog.quote_ident(i_schema)
        || '.' || pg_catalog.quote_ident(i_name) || '''';
    EXECUTE 'CREATE VIEW db4ai.v' || s_id::TEXT || ' WITH(security_barrier) AS SELECT ' || i_commands[5] || ', xc_node_id, ctid FROM db4ai.t' || s_id::TEXT;
    EXECUTE 'COMMENT ON VIEW db4ai.v' || s_id::TEXT || ' IS ''snapshot ' || pg_catalog.quote_ident(i_schema) || '.' || pg_catalog.quote_ident(i_name)
        || ' backed by db4ai.t' || s_id::TEXT || CASE WHEN pg_catalog.length(i_comment) > 0 THEN ' comment is "' || i_comment || '"' ELSE '' END || '''';
    EXECUTE 'GRANT SELECT ON db4ai.v' || s_id::TEXT || ' TO "' || i_owner || '" WITH GRANT OPTION';
    EXECUTE 'SELECT COUNT(*) FROM db4ai.v' || s_id::TEXT INTO STRICT row_count;

    -- store only original commands supplied by user
    i_commands := ARRAY[i_commands[1], i_commands[2], i_commands[3]];
    INSERT INTO db4ai.snapshot (id, root_id, schema, name, owner, commands, comment, published, row_count)
        VALUES (s_id, s_id, i_schema, i_name, i_owner, i_commands, i_comment, TRUE, row_count);

END;
$$;

alter function create_snapshot_internal(bigint, name, name, text[], text, name) owner to omm;

