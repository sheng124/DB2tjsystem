create view gs_total_memory_detail(nodename, memorytype, memorymbytes) as
SELECT *
FROM pv_total_memory_detail() pv_total_memory_detail(nodename, memorytype, memorymbytes);

alter table gs_total_memory_detail
    owner to omm;

