create view gs_session_stat(sessid, statid, statname, statunit, value) as
SELECT *
FROM pv_session_stat() pv_session_stat(sessid, statid, statname, statunit, value);

alter table gs_session_stat
    owner to omm;

