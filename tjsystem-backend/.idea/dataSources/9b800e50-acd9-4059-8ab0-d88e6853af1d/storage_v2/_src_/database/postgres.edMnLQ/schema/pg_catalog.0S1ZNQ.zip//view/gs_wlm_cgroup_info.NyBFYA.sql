create view gs_wlm_cgroup_info
            (cgroup_name, priority, usage_percent, shares, cpuacct, cpuset, relpath, valid, node_group) as
SELECT pg_stat_get_cgroup_info.cgroup_name,
       pg_stat_get_cgroup_info.percent AS priority,
       pg_stat_get_cgroup_info.usage_percent,
       pg_stat_get_cgroup_info.shares,
       pg_stat_get_cgroup_info.usage   AS cpuacct,
       pg_stat_get_cgroup_info.cpuset,
       pg_stat_get_cgroup_info.relpath,
       pg_stat_get_cgroup_info.valid,
       pg_stat_get_cgroup_info.node_group
FROM pg_stat_get_cgroup_info(NULL::integer) pg_stat_get_cgroup_info(cgroup_name, percent, usage_percent, shares, usage,
                                                                    cpuset, relpath, valid, node_group);

alter table gs_wlm_cgroup_info
    owner to omm;

