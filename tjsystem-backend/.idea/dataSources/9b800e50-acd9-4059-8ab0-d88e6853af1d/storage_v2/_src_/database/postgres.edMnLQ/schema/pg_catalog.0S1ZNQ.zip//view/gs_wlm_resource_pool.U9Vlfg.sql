create view gs_wlm_resource_pool
            (rpoid, respool, control_group, parentid, ref_count, active_points, running_count, waiting_count, io_limits,
             io_priority)
as
SELECT t.respool_oid  AS rpoid,
       r.respool_name AS respool,
       r.control_group,
       r.parentid,
       t.ref_count,
       t.active_points,
       t.running_count,
       t.waiting_count,
       t.iops_limits  AS io_limits,
       t.io_priority
FROM gs_wlm_get_resource_pool_info(0) t(respool_oid, ref_count, active_points, running_count, waiting_count,
                                        iops_limits, io_priority),
     pg_resource_pool r
WHERE t.respool_oid = r.oid;

alter table gs_wlm_resource_pool
    owner to omm;

