create function pgsysconf_pretty(OUT os_page_size text, OUT os_pages_free text, OUT os_total_pages text) returns record
    language sql
as
$$
select pg_catalog.pg_size_pretty(os_page_size) as os_page_size, pg_catalog.pg_size_pretty(os_pages_free * os_page_size)  as os_pages_free, pg_catalog.pg_size_pretty(os_total_pages * os_page_size) as os_total_pages from pg_catalog.pgsysconf()
$$;

comment on function pgsysconf_pretty(out text, out text, out text) is 'less than';

alter function pgsysconf_pretty(out text, out text, out text) owner to omm;

