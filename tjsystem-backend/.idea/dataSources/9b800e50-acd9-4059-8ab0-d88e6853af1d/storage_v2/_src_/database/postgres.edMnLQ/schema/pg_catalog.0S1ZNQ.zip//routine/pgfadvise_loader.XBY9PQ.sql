create function pgfadvise_loader(relname regclass, reltype "char", partition_name text, segment integer, load boolean, unload boolean, databit bit varying, OUT relpath text, OUT os_page_size bigint, OUT os_pages_free bigint, OUT pages_loaded bigint, OUT pages_unloaded bigint) returns SETOF record
    cost 1
    rows 1
    language sql
as
$$
SELECT pg_catalog.pgfadvise_loader($1, 'main', $2, $3, $4, $5, $6, $7)
$$;

comment on function pgfadvise_loader(regclass, "char", text, integer, boolean, boolean, bit varying, out text, out bigint, out bigint, out bigint, out bigint) is 'not equal';

alter function pgfadvise_loader(regclass, "char", text, integer, boolean, boolean, bit varying, out text, out bigint, out bigint, out bigint, out bigint) owner to omm;

