create function to_clob(character) returns clob
    immutable
    strict
    language sql
as
$$
select CAST($1 AS TEXT)
$$;

alter function to_clob(char) owner to omm;

