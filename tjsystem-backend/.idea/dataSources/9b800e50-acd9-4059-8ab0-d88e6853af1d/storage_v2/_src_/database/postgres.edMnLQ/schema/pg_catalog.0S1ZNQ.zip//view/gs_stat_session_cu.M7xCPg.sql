create view gs_stat_session_cu(mem_hit, hdd_sync_read, hdd_asyn_read) as
SELECT DISTINCT *
FROM pg_stat_session_cu() pg_stat_session_cu(mem_hit, hdd_sync_read, hdd_asyn_read);

alter table gs_stat_session_cu
    owner to omm;

