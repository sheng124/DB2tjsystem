create view gs_wlm_operator_statistics
            (queryid, pid, plan_node_id, plan_node_name, start_time, duration, status, query_dop, estimated_rows,
             tuple_processed, min_peak_memory, max_peak_memory, average_peak_memory, memory_skew_percent,
             min_spill_size, max_spill_size, average_spill_size, spill_skew_percent, min_cpu_time, max_cpu_time,
             total_cpu_time, cpu_skew_percent, warning)
as
SELECT t.*
FROM pg_stat_activity s,
     pg_stat_get_wlm_realtime_operator_info(NULL::integer) t(queryid, pid, plan_node_id, plan_node_name, start_time,
                                                             duration, status, query_dop, estimated_rows,
                                                             tuple_processed, min_peak_memory, max_peak_memory,
                                                             average_peak_memory, memory_skew_percent, min_spill_size,
                                                             max_spill_size, average_spill_size, spill_skew_percent,
                                                             min_cpu_time, max_cpu_time, total_cpu_time,
                                                             cpu_skew_percent, warning)
WHERE s.query_id = t.queryid;

alter table gs_wlm_operator_statistics
    owner to omm;

