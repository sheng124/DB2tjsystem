create function pgfadvise_sequential(relname regclass, OUT relpath text, OUT os_page_size bigint, OUT rel_os_pages bigint, OUT os_pages_free bigint) returns SETOF record
    cost 1
    rows 1
    language sql
as
$$
SELECT pg_catalog.pgfadvise($1, 'main', 40)
$$;

comment on function pgfadvise_sequential(regclass, out text, out bigint, out bigint, out bigint) is 'greater than';

alter function pgfadvise_sequential(regclass, out text, out bigint, out bigint, out bigint) owner to omm;

