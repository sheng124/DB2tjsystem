create function prepare_snapshot_internal(s_id bigint, p_id bigint, m_id bigint, r_id bigint, i_schema name, i_name name, i_commands text[], i_comment text, i_owner name, INOUT i_idx integer, INOUT i_exec_cmds text[], i_mapping name[] DEFAULT NULL::name[]) returns record
    security definer
    SET search_path = pg_catalog, pg_temp
    language plpgsql
as
$$
DECLARE
    command_str TEXT;     -- command string for iterator
    e_stack_act TEXT;     -- current stack for validation
    row_count BIGINT;     -- number of rows in this snapshot
BEGIN

    BEGIN
        RAISE EXCEPTION 'SECURITY_STACK_CHECK';
    EXCEPTION WHEN OTHERS THEN
        GET STACKED DIAGNOSTICS e_stack_act = PG_EXCEPTION_CONTEXT;

        IF CURRENT_SCHEMA = 'db4ai' THEN
            e_stack_act := pg_catalog.replace(e_stack_act, ' prepare_snapshot(', ' db4ai.prepare_snapshot(');
            e_stack_act := pg_catalog.replace(e_stack_act, ' prepare_snapshot_internal(', ' db4ai.prepare_snapshot_internal(');
            e_stack_act := pg_catalog.replace(e_stack_act, ' sample_snapshot(', ' db4ai.sample_snapshot(');
        END IF;

        IF e_stack_act LIKE E'referenced column: i_idx\n'
            'SQL statement "SELECT (db4ai.prepare_snapshot_internal(s_id, p_id, m_id, r_id, i_schema, s_name, i_commands, i_comment,\n'
            '                CURRENT_USER, idx, exec_cmds)).i_idx"\n%'
        THEN
            e_stack_act := pg_catalog.substr(e_stack_act, 200);
        END IF;

        IF    e_stack_act NOT SIMILAR TO 'PL/pgSQL function db4ai.prepare_snapshot\(name,name,text\[\],name,text\) line (184|550|616|723) at assignment%'
          AND e_stack_act NOT LIKE 'PL/pgSQL function db4ai.sample_snapshot(name,name,name[],numeric[],name[],text[]) line 224 at IF%'
        THEN
            RAISE EXCEPTION 'direct call to db4ai.prepare_snapshot_internal(bigint,bigint,bigint,bigint,name,name,text[],text,name,'
                            'int,text[],name[]) is not allowed'
            USING HINT = 'call public interface db4ai.prepare_snapshot instead';
        END IF;
    END;

    --generate rules from the mapping
    IF i_mapping IS NOT NULL THEN
        DECLARE
            sel_view TEXT := 'CREATE OR REPLACE VIEW db4ai.v' || s_id::TEXT || ' WITH(security_barrier) AS SELECT ';
            ins_grnt TEXT := 'GRANT INSERT (';
            ins_rule TEXT := 'CREATE OR REPLACE RULE _INSERT AS ON INSERT TO db4ai.v' || s_id::TEXT || ' DO INSTEAD INSERT INTO '
                               'db4ai.t' || coalesce(m_id, s_id)::TEXT || '(';
            ins_vals TEXT := ' VALUES (';
            upd_grnt TEXT;
            upd_rule TEXT;
            dist_key NAME[] := pg_catalog.array_agg(coalesce(m[1], pg_catalog.replace(m[2], '""', '"'))) FROM pg_catalog.regexp_matches(
                pg_catalog.getdistributekey('db4ai.t' || (coalesce(m_id, p_id))::TEXT),'([^\s",]+)|"((?:[^"]*"")*[^"]*)"', 'g') m;
        BEGIN

            FOR idx IN 3 .. pg_catalog.array_length(i_mapping, 1) BY 3 LOOP
                IF idx = 3 THEN
                    ins_grnt := ins_grnt || pg_catalog.quote_ident(i_mapping[idx]);
                    ins_rule := ins_rule || coalesce(i_mapping[idx-2], i_mapping[idx-1])::TEXT;
                    ins_vals := ins_vals || 'new.' || pg_catalog.quote_ident(i_mapping[idx]);
                ELSE
                    sel_view := sel_view || ', ';
                    ins_grnt := ins_grnt || ', ' || pg_catalog.quote_ident(i_mapping[idx]);
                    ins_rule := ins_rule || ', ' || coalesce(i_mapping[idx-2], i_mapping[idx-1]);
                    ins_vals := ins_vals || ', ' || 'new.' || pg_catalog.quote_ident(i_mapping[idx]);
                END IF;

                IF i_mapping[idx-2] IS NULL THEN -- handle shared columns without private (only CSS)
                    sel_view := sel_view || i_mapping[idx-1];
                ELSE
                    IF i_mapping[idx-1] IS NULL THEN -- handle sole private column (all MSS and added CSS columns)
                        sel_view := sel_view || i_mapping[idx-2];
                    ELSE -- handle shadowing (CSS CASE)
                        sel_view := sel_view || 'coalesce(' || i_mapping[idx-2] || ', ' || i_mapping[idx-1] || ')';
                    END IF;
                    IF dist_key IS NULL OR NOT i_mapping[idx-2] = ANY(dist_key) THEN   -- no updates on DISTRIBUTE BY columns
                        upd_grnt := CASE WHEN upd_grnt IS NULL  -- grant update only on private column
                            THEN 'GRANT UPDATE (' ELSE upd_grnt ||', ' END || pg_catalog.quote_ident(i_mapping[idx]);
                        upd_rule := CASE WHEN upd_rule IS NULL  -- update only private column
                            THEN 'CREATE OR REPLACE RULE _UPDATE AS ON UPDATE TO db4ai.v' || s_id::TEXT || ' DO INSTEAD UPDATE db4ai.t'
                                || coalesce(m_id, s_id)::TEXT || ' SET '
                            ELSE upd_rule || ', ' END
                            || i_mapping[idx-2] || '=new.' || pg_catalog.quote_ident(i_mapping[idx]); -- update private column
                    END IF;
                END IF;
                sel_view := sel_view || ' AS ' || pg_catalog.quote_ident(i_mapping[idx]);
            END LOOP;

            i_exec_cmds := i_exec_cmds || ARRAY [
                [ 'O', sel_view || ', xc_node_id, ctid FROM db4ai.t' || coalesce(m_id, s_id)::TEXT
                || CASE WHEN m_id IS NULL THEN '' ELSE ' WHERE _' || s_id::TEXT END ],
                [ 'O', 'GRANT SELECT, DELETE ON db4ai.v' || s_id::TEXT || ' TO "' || i_owner || '"'],
                [ 'O', ins_grnt || ') ON db4ai.v' || s_id::TEXT || ' TO "' || i_owner || '"'],
                [ 'O', ins_rule || CASE WHEN m_id IS NULL THEN ')' ELSE ', _' || s_id::TEXT || ')' END || ins_vals
                || CASE WHEN m_id IS NULL THEN ')' ELSE ', TRUE)' END ],
                [ 'O', 'CREATE OR REPLACE RULE _DELETE AS ON DELETE TO db4ai.v' || s_id::TEXT || ' DO INSTEAD '
                || CASE WHEN m_id IS NULL THEN 'DELETE FROM db4ai.t' || s_id::TEXT ELSE 'UPDATE db4ai.t' || m_id::TEXT || ' SET _' || s_id::TEXT || '=FALSE' END
                || ' WHERE t' || coalesce(m_id, s_id)::TEXT || '.xc_node_id=old.xc_node_id AND t' || coalesce(m_id, s_id)::TEXT || '.ctid=old.ctid' ] ];

            IF upd_rule IS NOT NULL THEN
                i_exec_cmds := i_exec_cmds || ARRAY [
                    [ 'O', upd_grnt || ') ON db4ai.v' || s_id::TEXT || ' TO "' || i_owner || '"'],
                    [ 'O', upd_rule || ' WHERE t' || coalesce(m_id, s_id)::TEXT || '.xc_node_id=old.xc_node_id AND t' || coalesce(m_id, s_id)::TEXT || '.ctid=old.ctid' ]];
            END IF;

            RETURN;
       END;
    END IF;

    -- Execute the queries
    LOOP EXIT WHEN i_idx = 1 + pg_catalog.array_length(i_exec_cmds, 1);
        CASE i_exec_cmds[i_idx][1]
        WHEN 'O' THEN
            -- RAISE NOTICE 'owner executing: %', i_exec_cmds[i_idx][2];
            EXECUTE i_exec_cmds[i_idx][2];
            i_idx := i_idx + 1;
        WHEN 'U' THEN
            RETURN;
        ELSE -- this should never happen
            RAISE EXCEPTION 'prepare snapshot internal error2: % %', idx, i_exec_cmds[idx];
        END CASE;
    END LOOP;

    EXECUTE 'DROP RULE IF EXISTS _INSERT ON db4ai.v' || s_id::TEXT;
    EXECUTE 'DROP RULE IF EXISTS _UPDATE ON db4ai.v' || s_id::TEXT;
    EXECUTE 'DROP RULE IF EXISTS _DELETE ON db4ai.v' || s_id::TEXT;
    EXECUTE 'COMMENT ON VIEW db4ai.v' || s_id::TEXT || ' IS ''snapshot ' || pg_catalog.quote_ident(i_schema) || '.' || pg_catalog.quote_ident(i_name)
        || ' backed by db4ai.t' || coalesce(m_id, s_id)::TEXT || CASE WHEN pg_catalog.length(i_comment) > 0 THEN ' comment is "' || i_comment
        || '"' ELSE '' END || '''';
    EXECUTE 'REVOKE ALL PRIVILEGES ON db4ai.v' || s_id::TEXT || ' FROM "' || i_owner || '"';
    EXECUTE 'GRANT SELECT ON db4ai.v' || s_id::TEXT || ' TO "' || i_owner || '" WITH GRANT OPTION';
    EXECUTE 'SELECT COUNT(*) FROM db4ai.v' || s_id::TEXT INTO STRICT row_count;

    INSERT INTO db4ai.snapshot (id, parent_id, matrix_id, root_id, schema, name, owner, commands, comment, row_count)
        VALUES (s_id, p_id, m_id, r_id, i_schema, i_name, '"' || i_owner || '"', i_commands, i_comment, row_count);

END;
$$;

alter function prepare_snapshot_internal(bigint, bigint, bigint, bigint, name, name, text[], text, name, inout integer, inout text[], name[]) owner to omm;

