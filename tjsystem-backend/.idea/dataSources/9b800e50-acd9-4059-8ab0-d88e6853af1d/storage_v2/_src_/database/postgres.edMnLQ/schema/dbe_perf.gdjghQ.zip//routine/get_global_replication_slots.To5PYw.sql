create function get_global_replication_slots(OUT node_name name, OUT slot_name text, OUT plugin text, OUT slot_type text, OUT datoid oid, OUT database name, OUT active boolean, OUT x_min xid, OUT catalog_xmin xid, OUT restart_lsn text, OUT dummy_standby boolean) returns SETOF record
    language plpgsql
as
$$
DECLARE
  row_data dbe_perf.replication_slots%rowtype;
  row_name record;
  query_str text;
  query_str_nodes text;
  BEGIN
    --Get all the node names
    query_str_nodes := 'select * from dbe_perf.node_name';
    FOR row_name IN EXECUTE(query_str_nodes) LOOP
      query_str := 'SELECT * FROM dbe_perf.replication_slots';
      FOR row_data IN EXECUTE(query_str) LOOP
        node_name := row_name.node_name;
        slot_name := row_data.slot_name;
        plugin := row_data.plugin;
        slot_type := row_data.slot_type;
        datoid := row_data.datoid;
        database := row_data.database;
        active := row_data.active;
        x_min := row_data.xmin;
        catalog_xmin := row_data.catalog_xmin;
        restart_lsn := row_data.restart_lsn;
        dummy_standby := row_data.dummy_standby;
        return next;
      END LOOP;
    END LOOP;
    return;
  END;
$$;

alter function get_global_replication_slots(out name, out text, out text, out text, out oid, out name, out boolean, out xid, out xid, out text, out boolean) owner to omm;

