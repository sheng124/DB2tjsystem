create view gs_wlm_ec_operator_statistics
            (queryid, plan_node_id, start_time, ec_status, ec_execute_datanode, ec_dsn, ec_username, ec_query,
             ec_libodbc_type, ec_fetch_count)
as
SELECT t.queryid,
       t.plan_node_id,
       t.start_time,
       t.ec_status,
       t.ec_execute_datanode,
       t.ec_dsn,
       t.ec_username,
       t.ec_query,
       t.ec_libodbc_type,
       t.ec_fetch_count
FROM pg_stat_activity s,
     pg_stat_get_wlm_realtime_ec_operator_info(NULL::integer) t(queryid, plan_node_id, plan_node_name, start_time,
                                                                ec_operator, ec_status, ec_execute_datanode, ec_dsn,
                                                                ec_username, ec_query, ec_libodbc_type, ec_fetch_count)
WHERE s.query_id = t.queryid
  AND t.ec_operator > 0;

alter table gs_wlm_ec_operator_statistics
    owner to omm;

