create function to_integer(nvarchar2) returns integer
    immutable
    strict
    language sql
as
$$
SELECT pg_catalog.int4in(pg_catalog.nvarchar2out($1))
$$;

alter function to_integer(nvarchar2) owner to omm;

