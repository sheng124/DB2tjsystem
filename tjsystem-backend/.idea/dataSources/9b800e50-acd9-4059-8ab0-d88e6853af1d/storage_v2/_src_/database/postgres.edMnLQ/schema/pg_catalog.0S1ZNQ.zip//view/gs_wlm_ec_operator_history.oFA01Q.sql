create view gs_wlm_ec_operator_history
            (queryid, plan_node_id, start_time, duration, tuple_processed, min_peak_memory, max_peak_memory,
             average_peak_memory, ec_status, ec_execute_datanode, ec_dsn, ec_username, ec_query, ec_libodbc_type)
as
SELECT pg_stat_get_wlm_ec_operator_info.queryid,
       pg_stat_get_wlm_ec_operator_info.plan_node_id,
       pg_stat_get_wlm_ec_operator_info.start_time,
       pg_stat_get_wlm_ec_operator_info.duration,
       pg_stat_get_wlm_ec_operator_info.tuple_processed,
       pg_stat_get_wlm_ec_operator_info.min_peak_memory,
       pg_stat_get_wlm_ec_operator_info.max_peak_memory,
       pg_stat_get_wlm_ec_operator_info.average_peak_memory,
       pg_stat_get_wlm_ec_operator_info.ec_status,
       pg_stat_get_wlm_ec_operator_info.ec_execute_datanode,
       pg_stat_get_wlm_ec_operator_info.ec_dsn,
       pg_stat_get_wlm_ec_operator_info.ec_username,
       pg_stat_get_wlm_ec_operator_info.ec_query,
       pg_stat_get_wlm_ec_operator_info.ec_libodbc_type
FROM pg_stat_get_wlm_ec_operator_info(0::oid) pg_stat_get_wlm_ec_operator_info(queryid, plan_node_id, plan_node_name,
                                                                               start_time, duration, tuple_processed,
                                                                               min_peak_memory, max_peak_memory,
                                                                               average_peak_memory, ec_operator,
                                                                               ec_status, ec_execute_datanode, ec_dsn,
                                                                               ec_username, ec_query, ec_libodbc_type,
                                                                               ec_fetch_count)
WHERE pg_stat_get_wlm_ec_operator_info.ec_operator > 0;

alter table gs_wlm_ec_operator_history
    owner to omm;

