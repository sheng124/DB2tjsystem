create view pg_running_xacts (handle, gxid, state, node, xmin, vacuum, timeline, prepare_xid, pid, next_xid) as
SELECT *
FROM pg_get_running_xacts() pg_get_running_xacts(handle, gxid, state, node, xmin, vacuum, timeline, prepare_xid, pid,
                                                 next_xid);

alter table pg_running_xacts
    owner to omm;

