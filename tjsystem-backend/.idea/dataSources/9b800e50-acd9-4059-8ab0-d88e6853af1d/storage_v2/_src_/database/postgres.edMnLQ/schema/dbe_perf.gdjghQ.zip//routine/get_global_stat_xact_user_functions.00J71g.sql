create function get_global_stat_xact_user_functions(OUT node_name name, OUT funcid oid, OUT schemaname name, OUT funcname name, OUT calls bigint, OUT total_time double precision, OUT self_time double precision) returns SETOF record
    language plpgsql
as
$$
DECLARE
  row_data dbe_perf.stat_xact_user_functions%rowtype;
  row_name record;
  query_str text;
  query_str_nodes text;
  BEGIN
    --Get all the node names
    query_str_nodes := 'select * from dbe_perf.node_name';
    FOR row_name IN EXECUTE(query_str_nodes) LOOP
      query_str := 'SELECT * FROM dbe_perf.stat_xact_user_functions';
      FOR row_data IN EXECUTE(query_str) LOOP
        node_name := row_name.node_name;
        funcid := row_data.funcid;
        schemaname := row_data.schemaname;
        funcname := row_data.funcname;
        calls := row_data.calls;
        total_time := row_data.total_time;
        self_time := row_data.self_time;
        return next;
      END LOOP;
    END LOOP;
    return;
  END;
$$;

alter function get_global_stat_xact_user_functions(out name, out oid, out name, out name, out bigint, out double precision, out double precision) owner to omm;

