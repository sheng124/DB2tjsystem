create view gs_session_memory(sessid, init_mem, used_mem, peak_mem) as
SELECT *
FROM pv_session_memory() pv_session_memory(sessid, init_mem, used_mem, peak_mem);

alter table gs_session_memory
    owner to omm;

