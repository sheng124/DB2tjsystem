create view pg_roles
            (rolname, rolsuper, rolinherit, rolcreaterole, rolcreatedb, rolcatupdate, rolcanlogin, rolreplication,
             rolauditadmin, rolsystemadmin, rolconnlimit, rolpassword, rolvalidbegin, rolvaliduntil, rolrespool,
             rolparentid, roltabspace, rolconfig, oid, roluseft, rolkind, nodegroup, roltempspace, rolspillspace,
             rolmonitoradmin, roloperatoradmin, rolpolicyadmin)
as
SELECT pg_authid.rolname,
       pg_authid.rolsuper,
       pg_authid.rolinherit,
       pg_authid.rolcreaterole,
       pg_authid.rolcreatedb,
       pg_authid.rolcatupdate,
       pg_authid.rolcanlogin,
       pg_authid.rolreplication,
       pg_authid.rolauditadmin,
       pg_authid.rolsystemadmin,
       pg_authid.rolconnlimit,
       '********'::text      AS rolpassword,
       pg_authid.rolvalidbegin,
       pg_authid.rolvaliduntil,
       pg_authid.rolrespool,
       pg_authid.rolparentid,
       pg_authid.roltabspace,
       s.setconfig           AS rolconfig,
       pg_authid.oid,
       pg_authid.roluseft,
       pg_authid.rolkind,
       pgxc_group.group_name AS nodegroup,
       pg_authid.roltempspace,
       pg_authid.rolspillspace,
       pg_authid.rolmonitoradmin,
       pg_authid.roloperatoradmin,
       pg_authid.rolpolicyadmin
FROM pg_authid
         LEFT JOIN pg_db_role_setting s ON pg_authid.oid = s.setrole AND s.setdatabase = 0::oid
         LEFT JOIN pgxc_group ON pg_authid.rolnodegroup = pgxc_group.oid
WHERE pg_authid.rolname = "current_user"()
   OR (SELECT pg_authid.rolcreaterole
       FROM pg_authid
       WHERE pg_authid.rolname = "current_user"())
   OR (SELECT pg_authid.rolsystemadmin
       FROM pg_authid
       WHERE pg_authid.rolname = "current_user"());

alter table pg_roles
    owner to omm;

