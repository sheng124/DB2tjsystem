create view pg_comm_status
            (node_name, rxpck_rate, txpck_rate, rxkbyte_rate, txkbyte_rate, buffer, memkbyte_libcomm, memkbyte_libpq,
             used_pm, used_sflow, used_rflow, used_rloop, stream)
as
SELECT *
FROM pg_comm_status() pg_comm_status(node_name, rxpck_rate, txpck_rate, rxkbyte_rate, txkbyte_rate, buffer,
                                     memkbyte_libcomm, memkbyte_libpq, used_pm, used_sflow, used_rflow, used_rloop,
                                     stream);

alter table pg_comm_status
    owner to omm;

