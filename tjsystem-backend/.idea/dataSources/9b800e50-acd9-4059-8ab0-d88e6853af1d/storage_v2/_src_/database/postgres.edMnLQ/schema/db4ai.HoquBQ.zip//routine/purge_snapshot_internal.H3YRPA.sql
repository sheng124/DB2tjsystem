create function purge_snapshot_internal(i_schema name, i_name name) returns void
    security definer
    SET search_path = pg_catalog, pg_temp
    language plpgsql
as
$$
DECLARE
    s_id BIGINT;         -- snapshot id
    p_id BIGINT;         -- parent id
    m_id BIGINT;         -- matrix id
    o_id BIGINT[];       -- other snapshot ids in same backing table
    pushed_cmds TEXT[];  -- commands to be pushed to descendants
    pushed_comment TEXT; -- comments to be pushed to descendants
    drop_cols NAME[];    -- orphaned columns
    e_stack_act TEXT;    -- current stack for validation
    affected BIGINT;     -- number of affected rows;
BEGIN

    BEGIN
        RAISE EXCEPTION 'SECURITY_STACK_CHECK';
    EXCEPTION WHEN OTHERS THEN
        GET STACKED DIAGNOSTICS e_stack_act = PG_EXCEPTION_CONTEXT;

        IF CURRENT_SCHEMA = 'db4ai' THEN
            e_stack_act := pg_catalog.replace(e_stack_act, 'ion pur', 'ion db4ai.pur');
        END IF;

        IF e_stack_act NOT LIKE 'referenced column: purge_snapshot_internal
SQL statement "SELECT db4ai.purge_snapshot_internal(i_schema, i_name)"
PL/pgSQL function db4ai.purge_snapshot(name,name) line 71 at PERFORM%'
        THEN
            RAISE EXCEPTION 'direct call to db4ai.purge_snapshot_internal(name,name) is not allowed'
            USING HINT = 'call public interface db4ai.purge_snapshot instead';
        END IF;
    END;

    -- check if snapshot exists
    BEGIN
        SELECT commands, comment, id, parent_id, matrix_id FROM db4ai.snapshot WHERE schema = i_schema AND name = i_name
            INTO STRICT pushed_cmds, pushed_comment, s_id, p_id, m_id;
    EXCEPTION WHEN NO_DATA_FOUND THEN
        RAISE EXCEPTION 'snapshot %.% does not exist' , pg_catalog.quote_ident(i_schema), pg_catalog.quote_ident(i_name);
    END;

    -- update descendants, if any
    UPDATE db4ai.snapshot SET
        parent_id = p_id,
        commands = pushed_cmds || commands,
        comment = CASE WHEN pushed_comment IS NULL THEN comment
                       WHEN comment IS NULL THEN pushed_comment
                       ELSE pushed_comment || ' | ' || comment END
        WHERE parent_id = s_id;
    IF p_id IS NULL AND SQL%ROWCOUNT > 0 THEN
        RAISE EXCEPTION 'cannot purge root snapshot ''%.%'' having dependent snapshots', pg_catalog.quote_ident(i_schema), pg_catalog.quote_ident(i_name)
        USING HINT = 'purge all dependent snapshots first';
    END IF;

    IF m_id IS NULL THEN
        EXECUTE 'DROP VIEW db4ai.v' || s_id::TEXT;
        EXECUTE 'DROP TABLE db4ai.t' || s_id::TEXT;
        RAISE NOTICE 'PURGE_SNAPSHOT: MSS backing table dropped';
    ELSE
        SELECT pg_catalog.array_agg(id) FROM db4ai.snapshot WHERE matrix_id = m_id AND id <> s_id INTO STRICT o_id;

        IF o_id IS NULL OR pg_catalog.array_length(o_id, 1) = 0 OR pg_catalog.array_length(o_id, 1) IS NULL THEN
            EXECUTE 'DROP VIEW db4ai.v' || s_id::TEXT;
            EXECUTE 'DROP TABLE db4ai.t' || m_id::TEXT;
            RAISE NOTICE 'PURGE_SNAPSHOT: CSS backing table dropped';
        ELSE
            EXECUTE 'DELETE FROM db4ai.t' || m_id::TEXT || ' WHERE _' || s_id::TEXT || ' AND NOT (_' || pg_catalog.array_to_string(o_id, ' OR _') || ')';
            GET DIAGNOSTICS affected = ROW_COUNT;

            SELECT pg_catalog.array_agg(pg_catalog.quote_ident(column_name))
            FROM  ( SELECT column_name
                    FROM information_schema.columns
                    WHERE table_schema = 'db4ai' AND table_name = ANY ( ('{v' || pg_catalog.array_to_string(s_id || o_id, ',v') || '}')::NAME[] )
                    GROUP BY column_name
                    HAVING SUM(CASE table_name WHEN 'v' || s_id::TEXT THEN 0 ELSE 1 END) = 0 )
            INTO STRICT drop_cols;

            EXECUTE 'DROP VIEW db4ai.v' || s_id::TEXT;

            EXECUTE 'ALTER TABLE db4ai.t' || m_id::TEXT || ' DROP _' || s_id::TEXT;
            RAISE NOTICE 'PURGE_SNAPSHOT: orphaned rows dropped: %, orphaned columns dropped: none', affected;
        END IF;
    END IF;

    DELETE FROM db4ai.snapshot WHERE schema = i_schema AND name = i_name;
    IF SQL%ROWCOUNT = 0 THEN
        -- checked before, this should never happen
        RAISE INFO 'snapshot %.% does not exist' , pg_catalog.quote_ident(i_schema), pg_catalog.quote_ident(i_name);
    END IF;
END;
$$;

alter function purge_snapshot_internal(name, name) owner to omm;

