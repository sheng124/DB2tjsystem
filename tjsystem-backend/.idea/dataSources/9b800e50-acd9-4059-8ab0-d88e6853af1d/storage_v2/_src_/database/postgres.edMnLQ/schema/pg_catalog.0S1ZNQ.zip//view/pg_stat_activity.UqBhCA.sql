create view pg_stat_activity
            (datid, datname, pid, sessionid, usesysid, usename, application_name, client_addr, client_hostname,
             client_port, backend_start, xact_start, query_start, state_change, waiting, enqueue, state, resource_pool,
             query_id, query, connection_info, unique_sql_id, trace_id)
as
SELECT s.datid,
       d.datname,
       s.pid,
       s.sessionid,
       s.usesysid,
       u.rolname AS usename,
       s.application_name,
       s.client_addr,
       s.client_hostname,
       s.client_port,
       s.backend_start,
       s.xact_start,
       s.query_start,
       s.state_change,
       s.waiting,
       s.enqueue,
       s.state,
       CASE
           WHEN s.srespool = 'unknown'::name THEN u.rolrespool
           ELSE s.srespool
           END   AS resource_pool,
       s.query_id,
       s.query,
       s.connection_info,
       s.unique_sql_id,
       s.trace_id
FROM pg_database d,
     pg_stat_get_activity_with_conninfo(NULL::bigint) s(datid, pid, sessionid, usesysid, application_name, state, query,
                                                        waiting, xact_start, query_start, backend_start, state_change,
                                                        client_addr, client_hostname, client_port, enqueue, query_id,
                                                        connection_info, srespool, global_sessionid, unique_sql_id,
                                                        trace_id),
     pg_authid u
WHERE s.datid = d.oid
  AND s.usesysid = u.oid;

alter table pg_stat_activity
    owner to omm;

