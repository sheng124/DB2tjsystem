create function timestamp_diff(text, timestamp without time zone, timestamp without time zone) returns bigint
    immutable
    strict
    cost 1
    language sql
as
$$
select pg_catalog.timestamp_diff($1, cast($2 as timestamp with time zone), cast($3 as timestamp with time zone))
$$;

alter function timestamp_diff(text, timestamp, timestamp) owner to omm;

