create view gs_get_control_group_info
            (name, type, gid, classgid, class, workload, shares, limits, wdlevel, cpucores, nodegroup, group_kind) as
SELECT *
FROM gs_get_control_group_info() gs_get_control_group_info(name text, type text, gid bigint, classgid bigint,
                                                           class text, workload text, shares bigint, limits bigint,
                                                           wdlevel bigint, cpucores text, nodegroup text,
                                                           group_kind text);

alter table gs_get_control_group_info
    owner to omm;

