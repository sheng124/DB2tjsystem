create function to_interval(character varying) returns interval
    immutable
    strict
    language sql
as
$$
select pg_catalog.interval_in(pg_catalog.varcharout($1), 0::Oid, -1)
$$;

alter function to_interval(varchar) owner to omm;

