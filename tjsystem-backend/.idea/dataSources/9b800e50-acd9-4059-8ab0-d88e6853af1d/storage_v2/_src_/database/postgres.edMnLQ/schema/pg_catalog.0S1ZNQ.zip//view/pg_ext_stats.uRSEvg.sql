create view pg_ext_stats
            (schemaname, tablename, attname, inherited, null_frac, avg_width, n_distinct, n_dndistinct,
             most_common_vals, most_common_freqs, most_common_vals_null, most_common_freqs_null, histogram_bounds)
as
SELECT n.nspname       AS schemaname,
       c.relname       AS tablename,
       s.stakey        AS attname,
       s.stainherit    AS inherited,
       s.stanullfrac   AS null_frac,
       s.stawidth      AS avg_width,
       s.stadistinct   AS n_distinct,
       s.stadndistinct AS n_dndistinct,
       CASE
           WHEN s.stakind1 = 1 THEN s.stavalues1
           WHEN s.stakind2 = 1 THEN s.stavalues2
           WHEN s.stakind3 = 1 THEN s.stavalues3
           WHEN s.stakind4 = 1 THEN s.stavalues4
           WHEN s.stakind5 = 1 THEN s.stavalues5
           ELSE NULL::anyarray
           END         AS most_common_vals,
       CASE
           WHEN s.stakind1 = 1 THEN s.stanumbers1
           WHEN s.stakind2 = 1 THEN s.stanumbers2
           WHEN s.stakind3 = 1 THEN s.stanumbers3
           WHEN s.stakind4 = 1 THEN s.stanumbers4
           WHEN s.stakind5 = 1 THEN s.stanumbers5
           ELSE NULL::real[]
           END         AS most_common_freqs,
       CASE
           WHEN s.stakind1 = 6 THEN s.stavalues1
           WHEN s.stakind2 = 6 THEN s.stavalues2
           WHEN s.stakind3 = 6 THEN s.stavalues3
           WHEN s.stakind4 = 6 THEN s.stavalues4
           WHEN s.stakind5 = 6 THEN s.stavalues5
           ELSE NULL::anyarray
           END         AS most_common_vals_null,
       CASE
           WHEN s.stakind1 = 6 THEN s.stanumbers1
           WHEN s.stakind2 = 6 THEN s.stanumbers2
           WHEN s.stakind3 = 6 THEN s.stanumbers3
           WHEN s.stakind4 = 6 THEN s.stanumbers4
           WHEN s.stakind5 = 6 THEN s.stanumbers5
           ELSE NULL::real[]
           END         AS most_common_freqs_null,
       CASE
           WHEN s.stakind1 = 2 THEN s.stavalues1
           WHEN s.stakind2 = 2 THEN s.stavalues2
           WHEN s.stakind3 = 2 THEN s.stavalues3
           WHEN s.stakind4 = 2 THEN s.stavalues4
           WHEN s.stakind5 = 2 THEN s.stavalues5
           ELSE NULL::anyarray
           END         AS histogram_bounds
FROM pg_statistic_ext s
         JOIN pg_class c ON c.oid = s.starelid AND s.starelkind = 'c'::"char"
         LEFT JOIN pg_namespace n ON n.oid = c.relnamespace;

alter table pg_ext_stats
    owner to omm;

