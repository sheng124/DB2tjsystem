create function time_text(time without time zone) returns text
    immutable
    strict
    language sql
as
$$
SELECT CAST(pg_catalog.time_out($1) AS text)
$$;

alter function time_text(time) owner to omm;

