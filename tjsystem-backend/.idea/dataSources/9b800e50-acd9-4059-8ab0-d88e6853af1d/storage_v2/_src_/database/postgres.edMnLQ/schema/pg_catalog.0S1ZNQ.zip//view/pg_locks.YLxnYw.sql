create view pg_locks
            (locktype, database, relation, page, tuple, bucket, virtualxid, transactionid, classid, objid, objsubid,
             virtualtransaction, pid, sessionid, mode, granted, fastpath, locktag, global_sessionid)
as
SELECT *
FROM pg_lock_status() l(locktype, database, relation, page, tuple, bucket, virtualxid, transactionid, classid, objid,
                        objsubid, virtualtransaction, pid, sessionid, mode, granted, fastpath, locktag,
                        global_sessionid);

alter table pg_locks
    owner to omm;

