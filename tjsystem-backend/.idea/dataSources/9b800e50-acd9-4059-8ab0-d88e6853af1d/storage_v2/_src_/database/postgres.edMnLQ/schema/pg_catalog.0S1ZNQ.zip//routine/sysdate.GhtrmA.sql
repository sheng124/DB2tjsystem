create function sysdate() returns timestamp without time zone
    language sql
as
$$
SELECT CURRENT_TIMESTAMP::timestamp(0)
$$;

alter function sysdate() owner to omm;

