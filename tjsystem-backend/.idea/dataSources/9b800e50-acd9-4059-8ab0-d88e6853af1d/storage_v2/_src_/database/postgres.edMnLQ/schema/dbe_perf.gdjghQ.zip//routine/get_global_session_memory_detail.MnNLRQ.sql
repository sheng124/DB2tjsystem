create function get_global_session_memory_detail(OUT node_name name, OUT sessid text, OUT sesstype text, OUT contextname text, OUT level smallint, OUT parent text, OUT totalsize bigint, OUT freesize bigint, OUT usedsize bigint) returns SETOF record
    language plpgsql
as
$$
DECLARE
  row_data dbe_perf.session_memory_detail%rowtype;
  row_name record;
  query_str text;
  query_str_nodes text;
  BEGIN
    --Get all the node names
    query_str_nodes := 'select * from dbe_perf.node_name';
    FOR row_name IN EXECUTE(query_str_nodes) LOOP
      query_str := 'SELECT * FROM dbe_perf.session_memory_detail';
      FOR row_data IN EXECUTE(query_str) LOOP
        node_name := row_name.node_name;
        sessid := row_data.sessid;
        sesstype := row_data.sesstype;
        contextname := row_data.contextname;
        level := row_data.level;
        parent := row_data.parent;
        totalsize := row_data.totalsize;
        freesize := row_data.freesize;
        usedsize := row_data.usedsize;
        return next;
      END LOOP;
    END LOOP;
    return;
  END;
$$;

alter function get_global_session_memory_detail(out name, out text, out text, out text, out smallint, out text, out bigint, out bigint, out bigint) owner to omm;

