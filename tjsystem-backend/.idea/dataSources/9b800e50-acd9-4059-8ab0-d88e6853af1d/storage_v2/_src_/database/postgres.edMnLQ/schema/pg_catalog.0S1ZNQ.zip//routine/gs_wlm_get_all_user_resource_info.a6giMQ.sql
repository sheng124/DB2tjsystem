create function gs_wlm_get_all_user_resource_info() returns SETOF record
    language plpgsql
as
$$
DECLARE                                                                    
	row_data record;                                 
	row_name record;                                                    
	query_str text;                                                    
	query_str2 text;                                              
	BEGIN                                                                   
		query_str := 'SELECT rolname FROM pg_authid';
		FOR row_name IN EXECUTE(query_str) LOOP              
			query_str2 := 'SELECT * FROM pg_catalog.gs_wlm_user_resource_info(''' || row_name.rolname || ''')';
			FOR row_data IN EXECUTE(query_str2) LOOP          
				return next row_data;
			END LOOP;                                          
		END LOOP;                                                  
		return;                                                    
	END;
$$;

alter function gs_wlm_get_all_user_resource_info() owner to omm;

