create view pg_statio_user_sequences(relid, schemaname, relname, blks_read, blks_hit) as
SELECT *
FROM pg_statio_all_sequences
WHERE (pg_statio_all_sequences.schemaname <> ALL (ARRAY ['pg_catalog'::name, 'information_schema'::name]))
  AND pg_statio_all_sequences.schemaname !~ '^pg_toast'::text;

alter table pg_statio_user_sequences
    owner to omm;

