create function archive_snapshot(i_schema name, i_name name) returns db4ai.snapshot_name
    SET client_min_messages = error
    language plpgsql
as
$$
DECLARE
    res db4ai.snapshot_name;    -- composite result
BEGIN

    IF i_schema IS NULL OR i_schema = '' THEN
        i_schema := CASE WHEN (SELECT 0=COUNT(*) FROM pg_catalog.pg_namespace WHERE nspname = CURRENT_USER) THEN 'public' ELSE CURRENT_USER END;
    END IF;

    -- return archived snapshot name
    res := db4ai.manage_snapshot_internal(i_schema, i_name, FALSE);
    return res;

END;
$$;

comment on function archive_snapshot(name, name) is 'Archive snapshot for preventing usage in model training';

alter function archive_snapshot(name, name) owner to omm;

