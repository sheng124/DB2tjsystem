create view pg_user
            (usename, usesysid, usecreatedb, usesuper, usecatupd, userepl, passwd, valbegin, valuntil, respool, parent,
             spacelimit, useconfig, nodegroup, tempspacelimit, spillspacelimit, usemonitoradmin, useoperatoradmin,
             usepolicyadmin)
as
SELECT pg_authid.rolname          AS usename,
       pg_authid.oid              AS usesysid,
       pg_authid.rolcreatedb      AS usecreatedb,
       pg_authid.rolsuper         AS usesuper,
       pg_authid.rolcatupdate     AS usecatupd,
       pg_authid.rolreplication   AS userepl,
       '********'::text           AS passwd,
       pg_authid.rolvalidbegin    AS valbegin,
       pg_authid.rolvaliduntil    AS valuntil,
       pg_authid.rolrespool       AS respool,
       pg_authid.rolparentid      AS parent,
       pg_authid.roltabspace      AS spacelimit,
       s.setconfig                AS useconfig,
       pgxc_group.group_name      AS nodegroup,
       pg_authid.roltempspace     AS tempspacelimit,
       pg_authid.rolspillspace    AS spillspacelimit,
       pg_authid.rolmonitoradmin  AS usemonitoradmin,
       pg_authid.roloperatoradmin AS useoperatoradmin,
       pg_authid.rolpolicyadmin   AS usepolicyadmin
FROM pg_authid
         LEFT JOIN pg_db_role_setting s ON pg_authid.oid = s.setrole AND s.setdatabase = 0::oid
         LEFT JOIN pgxc_group ON pg_authid.rolnodegroup = pgxc_group.oid
WHERE pg_authid.rolcanlogin;

alter table pg_user
    owner to omm;

