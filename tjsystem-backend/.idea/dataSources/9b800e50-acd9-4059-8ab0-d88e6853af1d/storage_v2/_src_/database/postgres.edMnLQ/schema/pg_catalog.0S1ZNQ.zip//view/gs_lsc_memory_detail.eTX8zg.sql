create view gs_lsc_memory_detail (threadid, tid, thrdtype, contextname, level, parent, totalsize, freesize, usedsize) as
SELECT *
FROM pv_thread_memory_detail() pv_thread_memory_detail(threadid, tid, thrdtype, contextname, level, parent, totalsize,
                                                       freesize, usedsize)
WHERE pv_thread_memory_detail.contextname ~~ '%LocalSysCache%'::text
   OR pv_thread_memory_detail.parent ~~ '%LocalSysCache%'::text;

alter table gs_lsc_memory_detail
    owner to omm;

