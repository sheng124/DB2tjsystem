create view pg_comm_delay (node_name, remote_name, remote_host, stream_num, min_delay, average, max_delay) as
SELECT DISTINCT *
FROM pg_comm_delay() pg_comm_delay(node_name, remote_name, remote_host, stream_num, min_delay, average, max_delay);

alter table pg_comm_delay
    owner to omm;

