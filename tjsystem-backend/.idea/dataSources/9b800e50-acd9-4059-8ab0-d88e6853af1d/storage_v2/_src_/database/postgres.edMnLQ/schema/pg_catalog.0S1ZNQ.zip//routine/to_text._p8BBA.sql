create function to_text(integer) returns text
    immutable
    strict
    language sql
as
$$
select CAST(pg_catalog.int4out($1) AS VARCHAR)
$$;

alter function to_text(integer) owner to omm;

