create view plan_table
            (statement_id, plan_id, id, operation, options, object_name, object_type, object_owner, projection, cost,
             cardinality) as
SELECT plan_table_data.statement_id,
       plan_table_data.plan_id,
       plan_table_data.id,
       plan_table_data.operation,
       plan_table_data.options,
       plan_table_data.object_name,
       plan_table_data.object_type,
       plan_table_data.object_owner,
       plan_table_data.projection,
       plan_table_data.cost,
       plan_table_data.cardinality
FROM plan_table_data
WHERE plan_table_data.session_id = pg_current_sessionid()
  AND plan_table_data.user_id = pg_current_userid();

alter table plan_table
    owner to omm;

