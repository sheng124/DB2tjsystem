create view gs_os_run_info(id, name, value, comments, cumulative) as
SELECT *
FROM pv_os_run_info() pv_os_run_info(id, name, value, comments, cumulative);

alter table gs_os_run_info
    owner to omm;

