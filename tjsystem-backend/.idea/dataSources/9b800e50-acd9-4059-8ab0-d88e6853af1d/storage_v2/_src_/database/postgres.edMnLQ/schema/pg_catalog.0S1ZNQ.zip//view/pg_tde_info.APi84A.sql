create view pg_tde_info(is_encrypt, g_tde_algo, remain) as
SELECT *
FROM pg_tde_info() pg_tde_info(is_encrypt, g_tde_algo, remain);

alter table pg_tde_info
    owner to omm;

