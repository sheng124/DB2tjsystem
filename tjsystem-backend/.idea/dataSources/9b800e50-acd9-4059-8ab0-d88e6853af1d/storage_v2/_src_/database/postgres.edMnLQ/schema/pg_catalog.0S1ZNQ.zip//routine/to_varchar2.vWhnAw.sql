create function to_varchar2(interval) returns character varying
    immutable
    strict
    language sql
as
$$
select CAST(pg_catalog.interval_out($1) AS VARCHAR2)
$$;

alter function to_varchar2(interval) owner to omm;

