create function to_nvarchar2(bigint) returns nvarchar2
    immutable
    strict
    language sql
as
$$
select CAST(pg_catalog.int8out($1) AS NVARCHAR2)
$$;

alter function to_nvarchar2(bigint) owner to omm;

