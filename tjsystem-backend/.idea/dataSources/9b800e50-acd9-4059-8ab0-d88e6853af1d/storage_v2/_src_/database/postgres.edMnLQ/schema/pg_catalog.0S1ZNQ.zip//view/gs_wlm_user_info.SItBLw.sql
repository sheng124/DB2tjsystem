create view gs_wlm_user_info
            (userid, username, sysadmin, rpoid, respool, parentid, totalspace, spacelimit, childcount, childlist) as
SELECT t.userid,
       s.rolname      AS username,
       t.sysadmin,
       t.rpoid,
       r.respool_name AS respool,
       t.parentid,
       t.totalspace,
       t.spacelimit,
       t.childcount,
       t.childlist
FROM pg_roles s,
     gs_wlm_get_user_info(NULL::integer) t(userid, sysadmin, rpoid, parentid, totalspace, spacelimit, childcount,
                                           childlist),
     pg_resource_pool r
WHERE s.oid = t.userid
  AND t.rpoid = r.oid;

alter table gs_wlm_user_info
    owner to omm;

