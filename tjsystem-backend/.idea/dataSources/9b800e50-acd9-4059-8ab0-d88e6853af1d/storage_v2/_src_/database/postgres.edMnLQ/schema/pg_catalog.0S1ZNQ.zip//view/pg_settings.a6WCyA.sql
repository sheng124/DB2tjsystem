create view pg_settings
            (name, setting, unit, category, short_desc, extra_desc, context, vartype, source, min_val, max_val,
             enumvals, boot_val, reset_val, sourcefile, sourceline)
as
SELECT *
FROM pg_show_all_settings() a(name, setting, unit, category, short_desc, extra_desc, context, vartype, source, min_val,
                              max_val, enumvals, boot_val, reset_val, sourcefile, sourceline);

alter table pg_settings
    owner to omm;

