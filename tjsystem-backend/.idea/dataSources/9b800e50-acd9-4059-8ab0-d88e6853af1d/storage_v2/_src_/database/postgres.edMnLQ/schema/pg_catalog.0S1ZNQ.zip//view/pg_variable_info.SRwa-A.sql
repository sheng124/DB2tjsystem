create view pg_variable_info
            (node_name, next_oid, next_xid, oldest_xid, xid_vac_limit, oldest_xid_db, last_extend_csn_logpage,
             start_extend_csn_logpage, next_commit_seqno, latest_completed_xid, startup_max_xid)
as
SELECT *
FROM pg_get_variable_info() pg_get_variable_info(node_name, next_oid, next_xid, oldest_xid, xid_vac_limit,
                                                 oldest_xid_db, last_extend_csn_logpage, start_extend_csn_logpage,
                                                 next_commit_seqno, latest_completed_xid, startup_max_xid);

alter table pg_variable_info
    owner to omm;

