create view sys_dummy(dummy) as
SELECT 'X'::text AS dummy;

alter table sys_dummy
    owner to omm;

