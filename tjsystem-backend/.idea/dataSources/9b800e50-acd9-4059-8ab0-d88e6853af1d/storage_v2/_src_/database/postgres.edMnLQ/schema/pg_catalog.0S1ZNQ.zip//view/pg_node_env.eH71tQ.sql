create view pg_node_env(node_name, host, process, port, installpath, datapath, log_directory) as
SELECT s.node_name,
       s.host,
       s.process,
       s.port,
       s.installpath,
       s.datapath,
       s.log_directory
FROM pg_stat_get_env() s(node_name, host, process, port, installpath, datapath, log_directory);

alter table pg_node_env
    owner to omm;

