create view pg_os_threads(node_name, pid, lwpid, thread_name, creation_time) as
SELECT s.node_name, s.pid, s.lwpid, s.thread_name, s.creation_time
FROM pg_stat_get_thread() s(node_name, pid, lwpid, thread_name, creation_time);

alter table pg_os_threads
    owner to omm;

