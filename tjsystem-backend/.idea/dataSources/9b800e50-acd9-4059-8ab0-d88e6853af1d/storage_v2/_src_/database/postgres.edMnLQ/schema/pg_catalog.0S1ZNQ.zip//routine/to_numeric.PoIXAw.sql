create function to_numeric(character) returns numeric
    immutable
    strict
    language sql
as
$$
SELECT pg_catalog.TO_NUMBER($1::TEXT)
$$;

alter function to_numeric(char) owner to omm;

