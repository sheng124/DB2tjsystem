create view gs_wlm_workload_records
            (node_name, thread_id, processid, time_stamp, username, memory, active_points, max_points, priority,
             resource_pool, status, control_group, enqueue, query, node_group)
as
SELECT p.node_name,
       s.threadid       AS thread_id,
       s.threadpid      AS processid,
       p.start_time     AS time_stamp,
       u.rolname        AS username,
       p.memory,
       p.actpts         AS active_points,
       p.maxpts         AS max_points,
       p.priority,
       p.resource_pool,
       s.current_status AS status,
       s.current_cgroup AS control_group,
       p.queue_type     AS enqueue,
       s.query,
       p.node_group
FROM pg_stat_get_session_wlmstat(NULL::integer) s(datid, threadid, sessionid, threadpid, usesysid, appname, query,
                                                  priority, block_time, elapsed_time, total_cpu_time, skew_percent,
                                                  statement_mem, active_points, dop_value, current_cgroup,
                                                  current_status, enqueue_state, attribute, is_plana, node_group,
                                                  srespool),
     pg_authid u,
     gs_wlm_get_workload_records(0) p(node_idx, query_pid, start_time, memory, actpts, maxpts, priority, resource_pool,
                                      node_name, queue_type, node_group)
WHERE p.query_pid = s.threadpid
  AND s.usesysid = u.oid;

alter table gs_wlm_workload_records
    owner to omm;

