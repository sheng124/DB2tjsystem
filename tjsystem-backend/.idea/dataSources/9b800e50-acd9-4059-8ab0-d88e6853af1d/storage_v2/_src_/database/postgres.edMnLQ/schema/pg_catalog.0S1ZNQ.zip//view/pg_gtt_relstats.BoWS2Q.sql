create view pg_gtt_relstats
            (schemaname, tablename, relfilenode, relpages, reltuples, relallvisible, relfrozenxid, relminmxid) as
SELECT n.nspname                                                                       AS schemaname,
       c.relname                                                                       AS tablename,
       (SELECT pg_get_gtt_relstats.relfilenode
        FROM pg_get_gtt_relstats(c.oid) pg_get_gtt_relstats(relfilenode, relpages, reltuples, relallvisible,
                                                            relfrozenxid, relminmxid)) AS relfilenode,
       (SELECT pg_get_gtt_relstats.relpages
        FROM pg_get_gtt_relstats(c.oid) pg_get_gtt_relstats(relfilenode, relpages, reltuples, relallvisible,
                                                            relfrozenxid, relminmxid)) AS relpages,
       (SELECT pg_get_gtt_relstats.reltuples
        FROM pg_get_gtt_relstats(c.oid) pg_get_gtt_relstats(relfilenode, relpages, reltuples, relallvisible,
                                                            relfrozenxid, relminmxid)) AS reltuples,
       (SELECT pg_get_gtt_relstats.relallvisible
        FROM pg_get_gtt_relstats(c.oid) pg_get_gtt_relstats(relfilenode, relpages, reltuples, relallvisible,
                                                            relfrozenxid, relminmxid)) AS relallvisible,
       (SELECT pg_get_gtt_relstats.relfrozenxid
        FROM pg_get_gtt_relstats(c.oid) pg_get_gtt_relstats(relfilenode, relpages, reltuples, relallvisible,
                                                            relfrozenxid, relminmxid)) AS relfrozenxid,
       (SELECT pg_get_gtt_relstats.relminmxid
        FROM pg_get_gtt_relstats(c.oid) pg_get_gtt_relstats(relfilenode, relpages, reltuples, relallvisible,
                                                            relfrozenxid, relminmxid)) AS relminmxid
FROM pg_class c
         LEFT JOIN pg_namespace n ON n.oid = c.relnamespace
WHERE c.relpersistence = 'g'::"char"
  AND (c.relkind = ANY (ARRAY ['r'::"char", 'p'::"char", 'i'::"char", 't'::"char"]));

alter table pg_gtt_relstats
    owner to omm;

