create function int8(text) returns bigint
    immutable
    strict
    language sql
as
$$
select cast(pg_catalog.to_number($1) as int8)
$$;

alter function int8(text) owner to omm;

