create function get_global_workload_transaction(OUT node_name name, OUT workload name, OUT commit_counter bigint, OUT rollback_counter bigint, OUT resp_min bigint, OUT resp_max bigint, OUT resp_avg bigint, OUT resp_total bigint, OUT bg_commit_counter bigint, OUT bg_rollback_counter bigint, OUT bg_resp_min bigint, OUT bg_resp_max bigint, OUT bg_resp_avg bigint, OUT bg_resp_total bigint) returns SETOF record
    language plpgsql
as
$$
DECLARE
  row_data dbe_perf.workload_transaction%rowtype;
  row_name record;
  query_str text;
  query_str_nodes text;
  BEGIN
    --Get all cn node names
    query_str_nodes := 'select * from dbe_perf.node_name';
    FOR row_name IN EXECUTE(query_str_nodes) LOOP
      query_str := 'SELECT * FROM dbe_perf.workload_transaction';
      FOR row_data IN EXECUTE(query_str) LOOP
        node_name := row_name.node_name;
        workload := row_data.workload;
        commit_counter := row_data.commit_counter;
        rollback_counter := row_data.rollback_counter;
        resp_min := row_data.resp_min;
        resp_max := row_data.resp_max;
        resp_avg := row_data.resp_avg;
        resp_total := row_data.resp_total;
        bg_commit_counter := row_data.bg_commit_counter;
        bg_rollback_counter := row_data.bg_rollback_counter;
        bg_resp_min := row_data.bg_resp_min;
        bg_resp_max := row_data.bg_resp_max;
        bg_resp_avg := row_data.bg_resp_avg;
        bg_resp_total := row_data.bg_resp_total;
        return next;
      END LOOP;
    END LOOP;
    return;
  END;
$$;

alter function get_global_workload_transaction(out name, out name, out bigint, out bigint, out bigint, out bigint, out bigint, out bigint, out bigint, out bigint, out bigint, out bigint, out bigint, out bigint) owner to omm;

