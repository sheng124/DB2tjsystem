create function to_bigint(character varying) returns bigint
    immutable
    strict
    language sql
as
$$
SELECT pg_catalog.int8in(pg_catalog.varcharout($1))
$$;

alter function to_bigint(varchar) owner to omm;

