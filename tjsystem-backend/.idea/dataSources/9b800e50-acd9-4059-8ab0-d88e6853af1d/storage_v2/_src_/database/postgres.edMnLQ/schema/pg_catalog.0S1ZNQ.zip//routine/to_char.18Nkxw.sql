create function to_char(real) returns character varying
    immutable
    strict
    language sql
as
$$
SELECT CAST(pg_catalog.float4out($1) AS VARCHAR2)
$$;

alter function to_char(real) owner to omm;

