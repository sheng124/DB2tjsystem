create view pg_comm_send_stream
            (node_name, local_tid, remote_name, remote_tid, idx, sid, tcp_sock, state, query_id, pn_id, send_smp,
             recv_smp, send_bytes, time, speed, quota, wait_quota)
as
SELECT s.node_name,
       s.local_tid,
       s.remote_name,
       s.remote_tid,
       s.idx,
       s.sid,
       s.tcp_sock,
       s.state,
       s.query_id,
       s.pn_id,
       s.send_smp,
       s.recv_smp,
       s.send_bytes,
       s."time",
       s.speed,
       s.quota,
       s.wait_quota
FROM pg_comm_send_stream() s(node_name, local_tid, remote_name, remote_tid, idx, sid, tcp_sock, state, query_id, pn_id,
                             send_smp, recv_smp, send_bytes, "time", speed, quota, wait_quota);

alter table pg_comm_send_stream
    owner to omm;

