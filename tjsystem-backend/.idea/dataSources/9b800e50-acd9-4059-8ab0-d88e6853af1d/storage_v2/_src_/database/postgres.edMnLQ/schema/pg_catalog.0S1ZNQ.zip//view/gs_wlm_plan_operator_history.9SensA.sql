create view gs_wlm_plan_operator_history
            (datname, queryid, plan_node_id, startup_time, total_time, actual_rows, max_peak_memory, query_dop,
             parent_node_id, left_child_id, right_child_id, operation, orientation, strategy, options, condition,
             projection)
as
SELECT *
FROM gs_stat_get_wlm_plan_operator_info(0::oid) gs_stat_get_wlm_plan_operator_info(datname, queryid, plan_node_id,
                                                                                   startup_time, total_time,
                                                                                   actual_rows, max_peak_memory,
                                                                                   query_dop, parent_node_id,
                                                                                   left_child_id, right_child_id,
                                                                                   operation, orientation, strategy,
                                                                                   options, condition, projection);

alter table gs_wlm_plan_operator_history
    owner to omm;

