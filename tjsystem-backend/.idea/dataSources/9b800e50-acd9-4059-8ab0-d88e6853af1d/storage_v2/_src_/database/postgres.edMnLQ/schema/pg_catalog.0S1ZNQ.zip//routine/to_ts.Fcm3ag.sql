create function to_ts(nvarchar2) returns timestamp without time zone
    immutable
    strict
    language sql
as
$$
select pg_catalog.timestamp_in(pg_catalog.nvarchar2out($1), 0::Oid, -1)
$$;

alter function to_ts(nvarchar2) owner to omm;

