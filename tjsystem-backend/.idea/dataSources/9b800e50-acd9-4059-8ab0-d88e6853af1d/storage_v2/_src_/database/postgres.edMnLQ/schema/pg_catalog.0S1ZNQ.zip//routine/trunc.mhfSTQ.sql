create function trunc(timestamp with time zone) returns timestamp without time zone
    immutable
    strict
    language sql
as
$$
SELECT CAST(DATE_TRUNC('day',$1) AS TIMESTAMP WITHOUT TIME ZONE);
$$;

alter function trunc(timestamp with time zone) owner to omm;

