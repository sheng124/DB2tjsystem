create view gs_session_memory_context (sessid, threadid, contextname, level, parent, totalsize, freesize, usedsize) as
SELECT *
FROM pv_session_memory_detail() pv_session_memory_detail(sessid, threadid, contextname, level, parent, totalsize,
                                                         freesize, usedsize);

alter table gs_session_memory_context
    owner to omm;

