create function login_audit_messages(flag boolean)
    returns TABLE(username text, database text, logintime timestamp with time zone, mytype text, result text, client_conninfo text)
    security definer
    language plpgsql
as
$$
DECLARE
user_id text;
user_name text;
db_name text;
SQL_STMT VARCHAR2(500);
fail_cursor REFCURSOR;
success_cursor REFCURSOR;
BEGIN
	SELECT pg_catalog.text(oid) FROM pg_catalog.pg_authid WHERE rolname=SESSION_USER INTO user_id;
	SELECT SESSION_USER INTO user_name;
	SELECT pg_catalog.CURRENT_DATABASE() INTO db_name;
	IF flag = true THEN 
		SQL_STMT := 'SELECT username,database,time,type,result,client_conninfo FROM pg_catalog.pg_query_audit(''1970-1-1'',''9999-12-31'') WHERE 
					type IN (''login_success'') AND username =' || pg_catalog.quote_literal(user_name) ||
					' AND database =' || pg_catalog.quote_literal(db_name) || ' AND userid =' || pg_catalog.quote_literal(user_id) || ';';
		OPEN success_cursor FOR EXECUTE SQL_STMT;		
		--search bottom up for all the success login info
		FETCH LAST FROM success_cursor into username, database, logintime, mytype, result, client_conninfo;
		FETCH BACKWARD FROM success_cursor into username, database, logintime, mytype, result, client_conninfo;
		IF FOUND THEN
			return next;
		END IF;
		CLOSE success_cursor;
	ELSE 
		SQL_STMT := 'SELECT username,database,time,type,result,client_conninfo FROM pg_catalog.pg_query_audit(''1970-1-1'',''9999-12-31'') WHERE 
					type IN (''login_success'', ''login_failed'') AND username =' || pg_catalog.quote_literal(user_name) ||
					' AND database =' || pg_catalog.quote_literal(db_name) || ' AND userid =' || pg_catalog.quote_literal(user_id) || ';';
		OPEN fail_cursor FOR EXECUTE SQL_STMT;
		--search bottom up 
		FETCH LAST FROM fail_cursor into username, database, logintime, mytype, result, client_conninfo;
		LOOP
			FETCH BACKWARD FROM fail_cursor into username, database, logintime, mytype, result, client_conninfo;
			EXIT WHEN NOT FOUND;
			IF mytype = 'login_failed' THEN 
				return next;
			ELSE 
			-- must be login_success
				EXIT;
			END IF;
		END LOOP;
		CLOSE fail_cursor;
	END IF;
END;
$$;

alter function login_audit_messages(boolean) owner to omm;

