create function int2(text) returns smallint
    immutable
    strict
    language sql
as
$$
select cast(pg_catalog.to_number($1) as int2)
$$;

alter function int2(text) owner to omm;

