create view gs_session_time(sessid, stat_id, stat_name, value) as
SELECT *
FROM pv_session_time() pv_session_time(sessid, stat_id, stat_name, value);

alter table gs_session_time
    owner to omm;

