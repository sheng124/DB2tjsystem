create function pgfadvise_willneed(relname regclass, OUT relpath text, OUT os_page_size bigint, OUT rel_os_pages bigint, OUT os_pages_free bigint) returns SETOF record
    cost 1
    rows 1
    language sql
as
$$
SELECT pg_catalog.pgfadvise($1, 'main', 10)
$$;

comment on function pgfadvise_willneed(regclass, out text, out bigint, out bigint, out bigint) is 'less than or equal';

alter function pgfadvise_willneed(regclass, out text, out bigint, out bigint, out bigint) owner to omm;

