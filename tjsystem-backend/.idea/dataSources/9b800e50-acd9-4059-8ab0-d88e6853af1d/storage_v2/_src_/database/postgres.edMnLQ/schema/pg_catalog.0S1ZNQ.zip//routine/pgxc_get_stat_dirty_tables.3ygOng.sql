create function pgxc_get_stat_dirty_tables(dirty_percent integer, n_tuples integer, schema text, OUT relid oid, OUT relname name, OUT schemaname name, OUT n_tup_ins bigint, OUT n_tup_upd bigint, OUT n_tup_del bigint, OUT n_live_tup bigint, OUT n_dead_tup bigint, OUT dirty_page_rate numeric) returns SETOF record
    language plpgsql
as
$$
DECLARE
	query_str text;
	row_data record;
	BEGIN
		query_str := 'SELECT oid relid, s.relname,s.schemaname,s.n_tup_ins,s.n_tup_upd,s.n_tup_del,s.n_live_tup,s.n_dead_tup,s.dirty_page_rate
						FROM pg_class p,
						(SELECT  relname, schemaname, pg_catalog.SUM(n_tup_ins) n_tup_ins, pg_catalog.SUM(n_tup_upd) n_tup_upd, pg_catalog.SUM(n_tup_del) n_tup_del, pg_catalog.SUM(n_live_tup) n_live_tup, pg_catalog.SUM(n_dead_tup) n_dead_tup, CAST((pg_catalog.SUM(n_dead_tup) / pg_catalog.SUM(n_dead_tup + n_live_tup + 0.00001) * 100) 
						AS pg_catalog.NUMERIC(5,2)) dirty_page_rate FROM pg_catalog.pgxc_stat_dirty_tables('||dirty_percent||','||n_tuples||','''||schema||''') GROUP BY (relname,schemaname)) s
						WHERE p.relname = s.relname AND p.relnamespace = (SELECT oid FROM pg_namespace WHERE nspname = s.schemaname) ORDER BY dirty_page_rate DESC';
		FOR row_data IN EXECUTE(query_str) LOOP
			relid = row_data.relid;
			relname = row_data.relname;
			schemaname = row_data.schemaname;
			n_tup_ins = row_data.n_tup_ins;
			n_tup_upd = row_data.n_tup_upd;
			n_tup_del = row_data.n_tup_del;
			n_live_tup = row_data.n_live_tup;
			n_dead_tup = row_data.n_dead_tup;
			dirty_page_rate = row_data.dirty_page_rate;
			return next;
		END LOOP;
	END;
$$;

alter function pgxc_get_stat_dirty_tables(integer, integer, text, out oid, out name, out name, out bigint, out bigint, out bigint, out bigint, out bigint, out numeric) owner to omm;

