create function to_char(text) returns text
    immutable
    strict
    language sql
as
$$
SELECT $1
$$;

alter function to_char(text) owner to omm;

