create function bitand(bigint, bigint) returns bigint
    immutable
    strict
    language sql
as
$$
select $1 & $2
$$;

alter function bitand(bigint, bigint) owner to omm;

