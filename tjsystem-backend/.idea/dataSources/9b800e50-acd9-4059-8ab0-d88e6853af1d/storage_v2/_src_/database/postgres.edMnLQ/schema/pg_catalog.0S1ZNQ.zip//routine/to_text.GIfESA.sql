create function to_text(smallint) returns text
    immutable
    strict
    language sql
as
$$
select CAST(pg_catalog.int2out($1) AS VARCHAR)
$$;

alter function to_text(smallint) owner to omm;

