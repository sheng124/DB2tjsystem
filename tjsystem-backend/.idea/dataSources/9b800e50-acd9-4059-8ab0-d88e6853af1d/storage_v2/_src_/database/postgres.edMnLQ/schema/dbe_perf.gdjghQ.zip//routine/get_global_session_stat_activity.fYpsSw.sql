create function get_global_session_stat_activity(OUT coorname text, OUT datid oid, OUT datname text, OUT pid bigint, OUT usesysid oid, OUT usename text, OUT application_name text, OUT client_addr inet, OUT client_hostname text, OUT client_port integer, OUT backend_start timestamp with time zone, OUT xact_start timestamp with time zone, OUT query_start timestamp with time zone, OUT state_change timestamp with time zone, OUT waiting boolean, OUT enqueue text, OUT state text, OUT resource_pool name, OUT query_id bigint, OUT query text, OUT unique_sql_id bigint, OUT trace_id text) returns SETOF record
    language plpgsql
as
$$
DECLARE
  row_data dbe_perf.session_stat_activity%rowtype;
  coor_name record;
  fet_active text;
  fetch_coor text;
  BEGIN
    --Get all cn node names
    fetch_coor := 'select * from dbe_perf.node_name';
    FOR coor_name IN EXECUTE(fetch_coor) LOOP
      coorname :=  coor_name.node_name;
      fet_active := 'SELECT * FROM dbe_perf.session_stat_activity';
      FOR row_data IN EXECUTE(fet_active) LOOP
        coorname := coorname;
        datid :=row_data.datid;
        datname := row_data.datname;
        pid := row_data.pid;
        usesysid :=row_data.usesysid;
        usename := row_data.usename;
        application_name := row_data.application_name;
        client_addr := row_data.client_addr;
        client_hostname :=row_data.client_hostname;
        client_port :=row_data.client_port;
        backend_start := row_data.backend_start;
        xact_start := row_data.xact_start;
        query_start := row_data.query_start;
        state_change := row_data.state_change;
        waiting := row_data.waiting;
        enqueue := row_data.enqueue;
        state := row_data.state;
        resource_pool :=row_data.resource_pool;
        query_id :=row_data.query_id;
        query := row_data.query;
        unique_sql_id := row_data.unique_sql_id;
        trace_id := row_data.trace_id;
        return next;
      END LOOP;
    END LOOP;
    return;
  END;
$$;

alter function get_global_session_stat_activity(out text, out oid, out text, out bigint, out oid, out text, out text, out inet, out text, out integer, out timestamp with time zone, out timestamp with time zone, out timestamp with time zone, out timestamp with time zone, out boolean, out text, out text, out name, out bigint, out text, out bigint, out text) owner to omm;

