create function repo_count_assertion() returns trigger
    language plpgsql
as
$$
BEGIN
    IF (SELECT COUNT(*) FROM repo WHERE author_id = NEW.author_id) >= 5 THEN
        RAISE EXCEPTION 'The count of repo is above 5.';
    END IF;
    RETURN NEW;
END;
$$;

alter function repo_count_assertion() owner to test;

