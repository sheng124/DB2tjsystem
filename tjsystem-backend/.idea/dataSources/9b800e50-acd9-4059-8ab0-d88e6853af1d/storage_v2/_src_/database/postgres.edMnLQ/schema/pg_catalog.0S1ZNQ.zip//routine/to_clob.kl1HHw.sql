create function to_clob(nvarchar2) returns clob
    immutable
    strict
    language sql
as
$$
select CAST($1 AS TEXT)
$$;

alter function to_clob(nvarchar2) owner to omm;

