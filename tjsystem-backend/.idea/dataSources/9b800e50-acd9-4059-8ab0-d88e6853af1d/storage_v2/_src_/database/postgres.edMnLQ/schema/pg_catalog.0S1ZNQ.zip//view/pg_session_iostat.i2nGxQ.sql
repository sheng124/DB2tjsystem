create view pg_session_iostat
            (query_id, mincurriops, maxcurriops, minpeakiops, maxpeakiops, io_limits, io_priority, query, node_group,
             curr_io_limits)
as
SELECT s.query_id,
       t.mincurr_iops AS mincurriops,
       t.maxcurr_iops AS maxcurriops,
       t.minpeak_iops AS minpeakiops,
       t.maxpeak_iops AS maxpeakiops,
       t.iops_limits  AS io_limits,
       CASE
           WHEN t.io_priority = 0 THEN 'None'::text
           WHEN t.io_priority = 10 THEN 'Low'::text
           WHEN t.io_priority = 20 THEN 'Medium'::text
           WHEN t.io_priority = 50 THEN 'High'::text
           ELSE NULL::text
           END        AS io_priority,
       s.query,
       s.node_group,
       t.curr_io_limits
FROM pg_stat_activity_ng s,
     pg_stat_get_wlm_session_iostat_info(0) t(threadid, maxcurr_iops, mincurr_iops, maxpeak_iops, minpeak_iops,
                                              iops_limits, io_priority, curr_io_limits)
WHERE s.pid = t.threadid;

alter table pg_session_iostat
    owner to omm;

