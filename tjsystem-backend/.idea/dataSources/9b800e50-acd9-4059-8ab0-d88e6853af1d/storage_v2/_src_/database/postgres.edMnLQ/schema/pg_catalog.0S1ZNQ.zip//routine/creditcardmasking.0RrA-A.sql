create function creditcardmasking(col text, letter character DEFAULT 'x'::bpchar) returns text
    language plpgsql
as
$$
declare 
    size INTEGER := 4;
begin
    return CASE WHEN pg_catalog.length(col) >= size THEN
        pg_catalog.REGEXP_REPLACE(pg_catalog.left(col, size*(-1)), '[\d+]', letter, 'g') || pg_catalog.right(col, size)
    ELSE
        col
    end;
end;
$$;

alter function creditcardmasking(text, char) owner to omm;

