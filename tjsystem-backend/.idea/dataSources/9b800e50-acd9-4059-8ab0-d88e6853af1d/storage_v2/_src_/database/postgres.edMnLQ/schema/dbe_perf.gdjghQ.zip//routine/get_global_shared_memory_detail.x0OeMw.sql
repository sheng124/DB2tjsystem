create function get_global_shared_memory_detail(OUT node_name name, OUT contextname text, OUT level smallint, OUT parent text, OUT totalsize bigint, OUT freesize bigint, OUT usedsize bigint) returns SETOF record
    language plpgsql
as
$$
DECLARE
  row_name record;
  row_data dbe_perf.shared_memory_detail%rowtype;
  query_str text;
  query_str_nodes text;
  BEGIN
    --Get all the node names
    query_str_nodes := 'select * from dbe_perf.node_name';
    FOR row_name IN EXECUTE(query_str_nodes) LOOP
        query_str := 'SELECT * FROM dbe_perf.shared_memory_detail';
        FOR row_data IN EXECUTE(query_str) LOOP
            node_name := row_name.node_name;
            contextname := row_data.contextname;
            level := row_data.level;
            parent := row_data.parent;
            totalsize := row_data.totalsize;
            freesize := row_data.freesize;
            usedsize := row_data.usedsize;
            RETURN NEXT;
        END LOOP;
    END LOOP;
    return;
  END;
$$;

alter function get_global_shared_memory_detail(out name, out text, out smallint, out text, out bigint, out bigint, out bigint) owner to omm;

