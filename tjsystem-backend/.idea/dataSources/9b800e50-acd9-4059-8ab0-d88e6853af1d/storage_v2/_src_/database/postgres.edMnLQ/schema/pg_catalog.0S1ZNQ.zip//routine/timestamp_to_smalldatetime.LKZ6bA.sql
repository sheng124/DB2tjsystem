create function timestamp_to_smalldatetime(timestamp without time zone) returns smalldatetime
    immutable
    strict
    language sql
as
$$
select pg_catalog.smalldatetime_in(pg_catalog.timestamp_out($1), 0::Oid, -1)
$$;

alter function timestamp_to_smalldatetime(timestamp) owner to omm;

