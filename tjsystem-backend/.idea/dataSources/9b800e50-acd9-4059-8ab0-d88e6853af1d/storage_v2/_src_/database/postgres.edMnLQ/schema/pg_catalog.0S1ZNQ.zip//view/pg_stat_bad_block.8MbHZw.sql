create view pg_stat_bad_block
            (nodename, databaseid, tablespaceid, relfilenode, bucketid, forknum, error_count, first_time, last_time) as
SELECT DISTINCT *
FROM pg_stat_bad_block() pg_stat_bad_block(nodename, databaseid, tablespaceid, relfilenode, bucketid, forknum,
                                           error_count, first_time, last_time);

alter table pg_stat_bad_block
    owner to omm;

