create function create_snapshot(i_schema name, i_name name, i_commands text[], i_vers name DEFAULT NULL::name, i_comment text DEFAULT NULL::text) returns db4ai.snapshot_name
    SET client_min_messages = error
    language plpgsql
as
$$
DECLARE
    s_id BIGINT;                    -- snapshot id
    s_mode VARCHAR(3);              -- current snapshot mode
    s_vers_del CHAR;                -- snapshot version delimiter, default '@'
    s_vers_sep CHAR;                -- snapshot version separator, default '.'
    separation_of_powers TEXT;      -- current separation of rights
    current_compatibility_mode TEXT;-- current compatibility mode
    none_represent INT;             -- 0 or NULL
    qual_name TEXT;                 -- qualified snapshot name
    command_str TEXT;               -- command string
    pattern TEXT;                   -- command pattern for matching
    proj_cmd TEXT;                  -- SELECT clause for create user view command (may be NULL if from_cmd is not NULL)
    from_cmd TEXT;                  -- FROM clause for command (may be NULL if proj_cmd is not NULL)
    dist_cmd TEXT;                  -- DISTRIBUTE BY clause for command (may be NULL)
    res db4ai.snapshot_name;        -- composite result
BEGIN

    -- obtain active message level
    BEGIN
        EXECUTE 'SET LOCAL client_min_messages TO ' || pg_catalog.current_setting('db4ai.message_level')::TEXT;
        RAISE INFO 'effective client_min_messages is ''%''', pg_catalog.upper(pg_catalog.current_setting('db4ai.message_level'));
    EXCEPTION WHEN OTHERS THEN
    END;

    -- obtain database state of separation of rights
    BEGIN
        separation_of_powers := pg_catalog.upper(pg_catalog.current_setting('enableSeparationOfDuty'));
    EXCEPTION WHEN OTHERS THEN
        separation_of_powers := 'OFF';
    END;

    IF separation_of_powers NOT IN ('ON', 'OFF') THEN
        RAISE EXCEPTION 'Uncertain state of separation of rights.';
    ELSIF separation_of_powers = 'ON' THEN
        RAISE EXCEPTION 'Snapshot is not supported in separation of rights';
    END IF;

    -- obtain active snapshot mode
    BEGIN
        s_mode := pg_catalog.upper(pg_catalog.current_setting('db4ai_snapshot_mode'));
    EXCEPTION WHEN OTHERS THEN
        s_mode := 'MSS';
    END;

    IF s_mode NOT IN ('CSS', 'MSS') THEN
        RAISE EXCEPTION 'invalid snapshot mode: ''%''', s_mode;
    END IF;

    -- obtain relevant configuration parameters
    BEGIN
        s_vers_del := pg_catalog.current_setting('db4ai_snapshot_version_delimiter');
    EXCEPTION WHEN OTHERS THEN
        s_vers_del := '@';
    END;
    BEGIN
        s_vers_sep := pg_catalog.current_setting('db4ai_snapshot_version_separator');
    EXCEPTION WHEN OTHERS THEN
        s_vers_sep := '.';
    END;

    -- check all input parameters
    IF i_schema IS NULL OR i_schema = '' THEN
        i_schema := CASE WHEN (SELECT 0=COUNT(*) FROM pg_catalog.pg_namespace WHERE nspname = CURRENT_USER) THEN 'public' ELSE CURRENT_USER END;
    END IF;

    IF i_name IS NULL OR i_name = '' THEN
        RAISE EXCEPTION 'i_name cannot be NULL or empty';
    ELSIF pg_catalog.strpos(i_name, s_vers_del) > 0 THEN
        RAISE EXCEPTION 'i_name must not contain ''%'' characters', s_vers_del;
    END IF;

    current_compatibility_mode := pg_catalog.current_setting('sql_compatibility');
    IF current_compatibility_mode = 'ORA' OR current_compatibility_mode = 'A' THEN
        none_represent := 0;
    ELSE
        none_represent := NULL;
    END IF;


    -- PG BUG: array_ndims('{}') or array_dims(ARRAY[]::INT[]) returns NULL
    IF i_commands IS NULL OR pg_catalog.array_length(i_commands, 1) = none_represent OR pg_catalog.array_length(i_commands, 2) <> none_represent THEN
        RAISE EXCEPTION 'i_commands array malformed'
        USING HINT = 'pass SQL commands as TEXT[] literal, e.g. ''{SELECT *, FROM public.t, DISTRIBUTE BY HASH(id)''';
    END IF;

    FOREACH command_str IN ARRAY i_commands LOOP
        IF command_str IS NULL THEN
            RAISE EXCEPTION 'i_commands array contains NULL values';
        END IF;
    END LOOP;

    FOREACH command_str IN ARRAY i_commands LOOP
        command_str := pg_catalog.btrim(command_str);
        pattern := pg_catalog.upper(pg_catalog.regexp_replace(pg_catalog.left(command_str, 30), '\s+', ' ', 'g'));
        IF pg_catalog.left(pattern, 7) = 'SELECT ' THEN
            IF proj_cmd IS NULL THEN
                proj_cmd := command_str;

                DECLARE
                    nested INT := 0;          -- level of nesting
                    quoted BOOLEAN := FALSE;  -- inside quoted identifier
                    cur_ch VARCHAR;           -- current character in tokenizer
                    idx INTEGER := 0;         -- loop counter, cannot use FOR .. iterator
                    start_pos INTEGER := 1;
                    stmt TEXT := command_str;
                BEGIN

-- BEGIN splitter code for testing

                    pattern := '';

                    LOOP
                        idx := idx + 1;
                        cur_ch := pg_catalog.substr(stmt, idx, 1);
                        EXIT WHEN cur_ch IS NULL OR cur_ch = '';

                        CASE cur_ch
                        WHEN '"' THEN
                            IF quoted AND pg_catalog.substr(stmt, idx + 1, 1) = '"' THEN
                                idx := idx + 1;
                            ELSE
                                quoted := NOT quoted;
                            END IF;
                            IF quoted THEN
                                CONTINUE;
                            END IF;
                        WHEN '(' THEN
                            nested := nested + 1;
                            CONTINUE;
                        WHEN ')' THEN
                            nested := nested - 1;
                            IF nested < 0 THEN
                                RAISE EXCEPTION 'syntax error at or near '')'' in ''%'' at position ''%''', stmt, idx;
                            END IF;
                            CONTINUE;
                        WHEN ' ' THEN
                            IF quoted OR nested > 0 THEN
                                CONTINUE;
                            ELSIF pattern IS NULL OR pg_catalog.length(pattern) = 0 THEN
                                start_pos := idx;
                                CONTINUE;
                            END IF;
                        WHEN ';' THEN
                            RAISE EXCEPTION 'syntax error at or near '';'' in ''%'' at position ''%''', stmt, idx;
                            CONTINUE;
                        ELSE
                            pattern := pattern || pg_catalog.upper(cur_ch);
                            CONTINUE;
                        END CASE;

-- END splitter code for testing

                        IF pattern = 'FROM' THEN
                            from_cmd := pg_catalog.substr(stmt, start_pos + 1);
                            proj_cmd := pg_catalog.left(stmt, start_pos - 1);
                            stmt := from_cmd;
                            nested := 0;
                            quoted := FALSE;
                            idx := idx - start_pos;
                            start_pos := 1;
                            RAISE NOTICE E'SELECT SPLITTING1\n%\n%\n%', stmt, proj_cmd, from_cmd;
                        ELSIF pattern = 'DISTRIBUTE' THEN
                            RAISE NOTICE E'SELECT SPLITTING2\n%\n%\n%', stmt, proj_cmd, from_cmd;
                            CONTINUE;
                        ELSIF pattern = 'DISTRIBUTEBY' THEN
                            dist_cmd := pg_catalog.substr(stmt, start_pos + 1);
                            from_cmd := pg_catalog.left(stmt, start_pos - 1);
                            RAISE NOTICE E'SELECT SPLITTING3\n%\n%\n%\n%', stmt, proj_cmd, from_cmd, dist_cmd;
                            EXIT;
                        END IF;
                        pattern := '';
                        start_pos := idx;
                    END LOOP;
                END;
            ELSE
                RAISE EXCEPTION 'multiple SELECT clauses in i_commands: ''%'' ''%''', proj_cmd, command_str;
            END IF;
        ELSIF pg_catalog.left(pattern, 5) = 'FROM ' THEN
            IF from_cmd IS NULL THEN
                from_cmd := command_str;
            ELSE
                RAISE EXCEPTION 'multiple FROM clauses in i_commands: ''%'' ''%''', from_cmd, command_str;
            END IF;
        ELSIF pg_catalog.left(pattern, 14) = 'DISTRIBUTE BY ' THEN
            IF dist_cmd IS NULL THEN
                dist_cmd := command_str;
            ELSE
                RAISE EXCEPTION 'multiple DISTRIBUTE BY clauses in i_commands: ''%'' ''%''', dist_cmd, command_str;
            END IF;
        ELSE
            RAISE EXCEPTION 'unrecognized command in i_commands: ''%''', command_str;
        END IF;
    END LOOP;

    IF proj_cmd IS NULL THEN
        -- minimum required input
         IF from_cmd IS NULL THEN
            RAISE EXCEPTION 'SELECT and FROM clauses are missing in i_commands';
         END IF;
        -- supply default projection
        proj_cmd := 'SELECT *';
    ELSE
        IF from_cmd IS NULL AND pg_catalog.strpos(pg_catalog.upper(proj_cmd), 'FROM ') = 0 THEN
            RAISE EXCEPTION 'FROM clause is missing in i_commands';
        END IF;
    END IF;

    IF dist_cmd IS NULL THEN
        dist_cmd := '';
    END IF;

    IF i_vers IS NULL OR i_vers = '' THEN
        i_vers := s_vers_del || '1' || s_vers_sep || '0' || s_vers_sep || '0';
    ELSE
        i_vers := pg_catalog.replace(i_vers, pg_catalog.chr(2), s_vers_sep);
        IF LEFT(i_vers, 1) <> s_vers_del THEN
            i_vers := s_vers_del || i_vers;
        ELSIF pg_catalog.char_length(i_vers ) < 2 THEN
            RAISE EXCEPTION 'illegal i_vers: ''%''', s_vers_del;
        END IF;
        IF pg_catalog.strpos(pg_catalog.substr(i_vers, 2), s_vers_del) > 0 THEN
            RAISE EXCEPTION 'i_vers may contain only one single, leading ''%'' character', s_vers_del
            USING HINT = 'specify snapshot version as [' || s_vers_del || ']x' || s_vers_sep || 'y' || s_vers_sep || 'z or ['
                || s_vers_del || ']label with optional, leading ''' || s_vers_del || '''';
        END IF;
    END IF;

    IF pg_catalog.char_length(i_name || i_vers) > 63 THEN
        RAISE EXCEPTION 'snapshot name too long: ''%''', i_name || i_vers;
    ELSE
        i_name := i_name || i_vers;
    END IF;

    -- the final name of the snapshot
    qual_name := pg_catalog.quote_ident(i_schema) || '.' || pg_catalog.quote_ident(i_name);

    -- check for duplicate snapshot
    IF 0 < (SELECT COUNT(*) FROM db4ai.snapshot WHERE schema = i_schema AND name = i_name) THEN
        RAISE EXCEPTION 'snapshot % already exists' , qual_name;
    END IF;

    --SELECT nextval('db4ai.snapshot_sequence') ==> -1 at first time fetch
    SELECT nextval('db4ai.snapshot_sequence') + 1 INTO STRICT s_id;

    -- execute using current user privileges
    DECLARE
        e_message TEXT;     -- exception message
    BEGIN
        EXECUTE 'CREATE TEMPORARY TABLE _db4ai_tmp_x' || s_id::TEXT || ' AS ' || proj_cmd
            || CASE WHEN from_cmd IS NULL THEN '' ELSE ' ' || from_cmd END;
    EXCEPTION WHEN undefined_table THEN
        GET STACKED DIAGNOSTICS e_message = MESSAGE_TEXT;

        -- during function invocation, search path is redirected to {pg_temp, pg_catalog, function_schema} and becomes immutable
        RAISE INFO 'could not resolve relation % using system-defined "search_path" setting during function invocation: ''%''',
            pg_catalog.substr(e_message, 10, 1 + pg_catalog.strpos(pg_catalog.substr(e_message,11), '" does not exist')),
            pg_catalog.array_to_string(pg_catalog.current_schemas(TRUE),', ')
            USING HINT = 'snapshots require schema-qualified table references, e.g. schema_name.table_name';
        RAISE;
    END;

    -- extract normalized projection list
    i_commands := ARRAY[proj_cmd, from_cmd, dist_cmd, '', ''];
    SELECT pg_catalog.string_agg(ident, ', '),
           pg_catalog.string_agg(ident::TEXT || ' AS f' || ordinal_position::TEXT, ', '),
           pg_catalog.string_agg('t' || s_id::TEXT || '.f' || ordinal_position::TEXT || ' AS ' || ident::TEXT, ', ')
    FROM ( SELECT ordinal_position, pg_catalog.quote_ident(column_name) AS ident
        FROM information_schema.columns
        WHERE table_schema = (SELECT nspname FROM pg_namespace WHERE oid=pg_catalog.pg_my_temp_schema())
            AND table_name = '_db4ai_tmp_x' || s_id::TEXT
            ORDER BY ordinal_position
    ) INTO STRICT proj_cmd, i_commands[4], i_commands[5];
    IF proj_cmd IS NULL THEN
        RAISE EXCEPTION 'create snapshot internal error1: %', s_id;
    END IF;

    -- finalize the snapshot using elevated privileges
    PERFORM db4ai.create_snapshot_internal(s_id, i_schema, i_name, i_commands, i_comment, CURRENT_USER);

    -- drop temporary view used for privilege transfer
    EXECUTE 'DROP TABLE _db4ai_tmp_x' || s_id::TEXT;

    -- create custom view, owned by current user
    EXECUTE 'CREATE VIEW ' || qual_name || ' WITH(security_barrier) AS SELECT ' || proj_cmd || ' FROM db4ai.v' || s_id::TEXT;
    EXECUTE 'COMMENT ON VIEW ' || qual_name || ' IS ''snapshot view backed by db4ai.v' || s_id::TEXT
        || CASE WHEN pg_catalog.length(i_comment) > 0 THEN ' comment is "' || i_comment || '"' ELSE '' END || '''';
    EXECUTE 'ALTER VIEW ' || qual_name || ' OWNER TO "' || CURRENT_USER::TEXT || '"';

    -- return final snapshot name
    res := ROW(i_schema, i_name);
    -- PG BUG: PG 9.2 cannot return composite type, only a reference to a variable of composite type
    return res;

END;
$$;

comment on function create_snapshot(name, name, text[], name, text) is 'Create a new snapshot';

alter function create_snapshot(name, name, text[], name, text) owner to omm;

