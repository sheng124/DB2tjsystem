create view gs_sql_count
            (node_name, user_name, select_count, update_count, insert_count, delete_count, mergeinto_count, ddl_count,
             dml_count, dcl_count, total_select_elapse, avg_select_elapse, max_select_elapse, min_select_elapse,
             total_update_elapse, avg_update_elapse, max_update_elapse, min_update_elapse, total_insert_elapse,
             avg_insert_elapse, max_insert_elapse, min_insert_elapse, total_delete_elapse, avg_delete_elapse,
             max_delete_elapse, min_delete_elapse)
as
SELECT pg_stat_get_sql_count.node_name::name AS node_name,
       pg_stat_get_sql_count.user_name::name AS user_name,
       pg_stat_get_sql_count.select_count,
       pg_stat_get_sql_count.update_count,
       pg_stat_get_sql_count.insert_count,
       pg_stat_get_sql_count.delete_count,
       pg_stat_get_sql_count.mergeinto_count,
       pg_stat_get_sql_count.ddl_count,
       pg_stat_get_sql_count.dml_count,
       pg_stat_get_sql_count.dcl_count,
       pg_stat_get_sql_count.total_select_elapse,
       pg_stat_get_sql_count.avg_select_elapse,
       pg_stat_get_sql_count.max_select_elapse,
       pg_stat_get_sql_count.min_select_elapse,
       pg_stat_get_sql_count.total_update_elapse,
       pg_stat_get_sql_count.avg_update_elapse,
       pg_stat_get_sql_count.max_update_elapse,
       pg_stat_get_sql_count.min_update_elapse,
       pg_stat_get_sql_count.total_insert_elapse,
       pg_stat_get_sql_count.avg_insert_elapse,
       pg_stat_get_sql_count.max_insert_elapse,
       pg_stat_get_sql_count.min_insert_elapse,
       pg_stat_get_sql_count.total_delete_elapse,
       pg_stat_get_sql_count.avg_delete_elapse,
       pg_stat_get_sql_count.max_delete_elapse,
       pg_stat_get_sql_count.min_delete_elapse
FROM pg_stat_get_sql_count() pg_stat_get_sql_count(node_name, user_name, select_count, update_count, insert_count,
                                                   delete_count, mergeinto_count, ddl_count, dml_count, dcl_count,
                                                   total_select_elapse, avg_select_elapse, max_select_elapse,
                                                   min_select_elapse, total_update_elapse, avg_update_elapse,
                                                   max_update_elapse, min_update_elapse, total_insert_elapse,
                                                   avg_insert_elapse, max_insert_elapse, min_insert_elapse,
                                                   total_delete_elapse, avg_delete_elapse, max_delete_elapse,
                                                   min_delete_elapse);

alter table gs_sql_count
    owner to omm;

