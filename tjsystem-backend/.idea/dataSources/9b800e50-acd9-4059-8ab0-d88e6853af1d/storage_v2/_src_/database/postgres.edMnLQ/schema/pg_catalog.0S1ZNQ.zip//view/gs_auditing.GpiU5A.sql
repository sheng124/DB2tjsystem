create view gs_auditing (polname, pol_type, polenabled, access_type, label_name, priv_object, filter_name) as
SELECT *
FROM gs_auditing_privilege
UNION ALL
SELECT *
FROM gs_auditing_access
ORDER BY 1;

alter table gs_auditing
    owner to omm;

