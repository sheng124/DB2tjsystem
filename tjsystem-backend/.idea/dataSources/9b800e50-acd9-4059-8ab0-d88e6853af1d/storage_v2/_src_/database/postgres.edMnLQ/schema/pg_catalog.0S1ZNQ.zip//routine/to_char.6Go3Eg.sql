create function to_char(bigint) returns character varying
    immutable
    strict
    language sql
as
$$
SELECT CAST(pg_catalog.int8out($1) AS VARCHAR2)
$$;

alter function to_char(bigint) owner to omm;

