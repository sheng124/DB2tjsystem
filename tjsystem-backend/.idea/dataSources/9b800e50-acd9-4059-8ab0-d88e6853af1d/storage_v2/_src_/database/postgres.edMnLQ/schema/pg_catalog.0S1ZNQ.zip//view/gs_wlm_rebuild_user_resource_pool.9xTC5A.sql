create view gs_wlm_rebuild_user_resource_pool(gs_wlm_rebuild_user_resource_pool) as
SELECT *
FROM gs_wlm_rebuild_user_resource_pool(0::text) gs_wlm_rebuild_user_resource_pool(gs_wlm_rebuild_user_resource_pool);

alter table gs_wlm_rebuild_user_resource_pool
    owner to omm;

