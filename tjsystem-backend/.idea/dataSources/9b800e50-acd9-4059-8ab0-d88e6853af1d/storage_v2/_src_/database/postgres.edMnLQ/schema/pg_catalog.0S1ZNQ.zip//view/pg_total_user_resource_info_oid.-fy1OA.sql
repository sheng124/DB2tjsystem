create view pg_total_user_resource_info_oid
            (userid, used_memory, total_memory, used_cpu, total_cpu, used_space, total_space, used_temp_space,
             total_temp_space, used_spill_space, total_spill_space, read_kbytes, write_kbytes, read_counts,
             write_counts, read_speed, write_speed)
as
SELECT *
FROM gs_wlm_get_all_user_resource_info() gs_wlm_get_all_user_resource_info(userid oid, used_memory integer,
                                                                           total_memory integer,
                                                                           used_cpu double precision, total_cpu integer,
                                                                           used_space bigint, total_space bigint,
                                                                           used_temp_space bigint,
                                                                           total_temp_space bigint,
                                                                           used_spill_space bigint,
                                                                           total_spill_space bigint, read_kbytes bigint,
                                                                           write_kbytes bigint, read_counts bigint,
                                                                           write_counts bigint,
                                                                           read_speed double precision,
                                                                           write_speed double precision);

alter table pg_total_user_resource_info_oid
    owner to omm;

