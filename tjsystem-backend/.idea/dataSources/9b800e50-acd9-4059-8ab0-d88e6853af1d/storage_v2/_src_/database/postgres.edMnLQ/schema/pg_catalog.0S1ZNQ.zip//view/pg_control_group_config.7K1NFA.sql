create view pg_control_group_config(pg_control_group_config) as
SELECT *
FROM pg_control_group_config() pg_control_group_config(pg_control_group_config);

alter table pg_control_group_config
    owner to omm;

