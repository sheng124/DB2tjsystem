create view pg_gtt_attached_pids(schemaname, tablename, relid, pids, sessionids) as
SELECT n.nspname                                                                         AS schemaname,
       c.relname                                                                         AS tablename,
       c.oid                                                                             AS relid,
       ARRAY(SELECT pg_gtt_attached_pid.pid
             FROM pg_gtt_attached_pid(c.oid) pg_gtt_attached_pid(relid, pid, sessionid)) AS pids,
       ARRAY(SELECT pg_gtt_attached_pid.sessionid
             FROM pg_gtt_attached_pid(c.oid) pg_gtt_attached_pid(relid, pid, sessionid)) AS sessionids
FROM pg_class c
         LEFT JOIN pg_namespace n ON n.oid = c.relnamespace
WHERE c.relpersistence = 'g'::"char"
  AND (c.relkind = ANY (ARRAY ['r'::"char", 'S'::"char", 'L'::"char"]));

alter table pg_gtt_attached_pids
    owner to omm;

