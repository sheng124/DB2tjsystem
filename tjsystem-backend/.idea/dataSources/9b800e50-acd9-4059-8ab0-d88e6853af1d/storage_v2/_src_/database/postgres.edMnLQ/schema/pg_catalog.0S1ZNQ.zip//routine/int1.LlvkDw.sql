create function int1(text) returns tinyint
    immutable
    strict
    language sql
as
$$
select cast(pg_catalog.to_number($1) as int1)
$$;

alter function int1(text) owner to omm;

