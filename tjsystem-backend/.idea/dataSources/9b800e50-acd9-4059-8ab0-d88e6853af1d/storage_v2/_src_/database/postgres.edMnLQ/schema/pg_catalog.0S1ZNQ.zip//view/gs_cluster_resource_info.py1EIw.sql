create view gs_cluster_resource_info
            (min_mem_util, max_mem_util, min_cpu_util, max_cpu_util, min_io_util, max_io_util, used_mem_rate) as
SELECT *
FROM pg_stat_get_wlm_node_resource_info(0) pg_stat_get_wlm_node_resource_info(min_mem_util, max_mem_util, min_cpu_util,
                                                                              max_cpu_util, min_io_util, max_io_util,
                                                                              used_mem_rate);

alter table gs_cluster_resource_info
    owner to omm;

