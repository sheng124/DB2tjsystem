create function to_char(numeric) returns character varying
    immutable
    strict
    language sql
as
$$
SELECT CAST(pg_catalog.numeric_out($1) AS VARCHAR2)
$$;

alter function to_char(numeric) owner to omm;

