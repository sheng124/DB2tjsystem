create function to_nvarchar2(integer) returns nvarchar2
    immutable
    strict
    language sql
as
$$
select CAST(pg_catalog.int4out($1) AS NVARCHAR2)
$$;

alter function to_nvarchar2(integer) owner to omm;

