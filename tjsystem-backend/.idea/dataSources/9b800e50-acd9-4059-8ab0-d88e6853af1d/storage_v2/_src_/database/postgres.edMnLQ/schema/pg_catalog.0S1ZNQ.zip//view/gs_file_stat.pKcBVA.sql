create view gs_file_stat
            (filenum, dbid, spcid, phyrds, phywrts, phyblkrd, phyblkwrt, readtim, writetim, avgiotim, lstiotim,
             miniotim, maxiowtm) as
SELECT *
FROM pg_stat_get_file_stat() pg_stat_get_file_stat(filenum, dbid, spcid, phyrds, phywrts, phyblkrd, phyblkwrt, readtim,
                                                   writetim, avgiotim, lstiotim, miniotim, maxiowtm);

alter table gs_file_stat
    owner to omm;

