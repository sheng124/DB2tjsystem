create function to_ts(character varying) returns timestamp without time zone
    immutable
    strict
    language sql
as
$$
select pg_catalog.timestamp_in(pg_catalog.varcharout($1), 0::Oid, -1)
$$;

alter function to_ts(varchar) owner to omm;

