create function to_integer(character varying) returns integer
    immutable
    strict
    language sql
as
$$
SELECT pg_catalog.int4in(pg_catalog.varcharout($1))
$$;

alter function to_integer(varchar) owner to omm;

