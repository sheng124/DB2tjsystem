create view gs_session_memory_statistics
            (datid, usename, pid, start_time, min_peak_memory, max_peak_memory, spill_info, query, node_group,
             top_mem_dn) as
SELECT s.datid,
       s.usename,
       s.pid,
       s.query_start AS start_time,
       t.min_peak_memory,
       t.max_peak_memory,
       t.spill_info,
       s.query,
       s.node_group,
       t.top_mem_dn
FROM pg_stat_activity_ng s,
     pg_stat_get_wlm_realtime_session_info(NULL::integer) t(nodename, threadid, block_time, duration,
                                                            estimate_total_time, estimate_left_time, schemaname,
                                                            query_band, spill_info, control_group, estimate_memory,
                                                            min_peak_memory, max_peak_memory, average_peak_memory,
                                                            memory_skew_percent, min_spill_size, max_spill_size,
                                                            average_spill_size, spill_skew_percent, min_dn_time,
                                                            max_dn_time, average_dn_time, dntime_skew_percent,
                                                            min_cpu_time, max_cpu_time, total_cpu_time,
                                                            cpu_skew_percent, min_peak_iops, max_peak_iops,
                                                            average_peak_iops, iops_skew_percent, warning, query,
                                                            query_plan, cpu_top1_node_name, cpu_top2_node_name,
                                                            cpu_top3_node_name, cpu_top4_node_name, cpu_top5_node_name,
                                                            mem_top1_node_name, mem_top2_node_name, mem_top3_node_name,
                                                            mem_top4_node_name, mem_top5_node_name, cpu_top1_value,
                                                            cpu_top2_value, cpu_top3_value, cpu_top4_value,
                                                            cpu_top5_value, mem_top1_value, mem_top2_value,
                                                            mem_top3_value, mem_top4_value, mem_top5_value, top_mem_dn,
                                                            top_cpu_dn)
WHERE s.pid = t.threadid;

alter table gs_session_memory_statistics
    owner to omm;

