create function to_text(smalldatetime) returns text
    immutable
    strict
    language sql
as
$$
select CAST(pg_catalog.smalldatetime_out($1) AS VARCHAR2)
$$;

alter function to_text(smalldatetime) owner to omm;

