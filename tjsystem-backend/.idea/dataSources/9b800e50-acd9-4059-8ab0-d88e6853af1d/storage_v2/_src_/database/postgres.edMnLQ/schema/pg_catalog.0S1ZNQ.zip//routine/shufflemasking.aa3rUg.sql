create function shufflemasking(col text) returns text
    language plpgsql
as
$$
declare 
    index INTEGER := 0;
    rd INTEGER;
    size INTEGER := pg_catalog.length(col);
    tmp text := col;
    res text := '';
begin
    while size > 0 loop 
        rd := pg_catalog.floor(pg_catalog.random() * pg_catalog.length(tmp) + 1);
        res := res || pg_catalog.right(pg_catalog.left(tmp, rd), 1);
        tmp := pg_catalog.left(tmp, rd - 1) || pg_catalog.right(tmp, pg_catalog.length(tmp) - rd);
        size := size - 1;
    END loop;
    return res;
end;
$$;

alter function shufflemasking(text) owner to omm;

