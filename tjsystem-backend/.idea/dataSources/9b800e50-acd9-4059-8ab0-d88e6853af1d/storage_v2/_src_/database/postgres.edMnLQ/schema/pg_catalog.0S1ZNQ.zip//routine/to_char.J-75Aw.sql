create function to_char(integer) returns character varying
    immutable
    strict
    language sql
as
$$
SELECT CAST(pg_catalog.int4out($1) AS VARCHAR2)
$$;

alter function to_char(integer) owner to omm;

