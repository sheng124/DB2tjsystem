create function publish_snapshot(i_schema name, i_name name) returns db4ai.snapshot_name
    SET client_min_messages = error
    language plpgsql
as
$$
DECLARE
    res db4ai.snapshot_name;    -- composite result
BEGIN

    IF i_schema IS NULL OR i_schema = '' THEN
        i_schema := CASE WHEN (SELECT 0=COUNT(*) FROM pg_catalog.pg_namespace WHERE nspname = CURRENT_USER) THEN 'public' ELSE CURRENT_USER END;
    END IF;

    -- return published snapshot name
    res := db4ai.manage_snapshot_internal(i_schema, i_name, TRUE);
    return res;

END;
$$;

comment on function publish_snapshot(name, name) is 'Publish snapshot for allowing usage in model training';

alter function publish_snapshot(name, name) owner to omm;

