create view pg_tables
            (schemaname, tablename, tableowner, tablespace, hasindexes, hasrules, hastriggers, tablecreator, created,
             last_ddl_time)
as
SELECT n.nspname                   AS schemaname,
       c.relname                   AS tablename,
       pg_get_userbyid(c.relowner) AS tableowner,
       t.spcname                   AS tablespace,
       c.relhasindex               AS hasindexes,
       c.relhasrules               AS hasrules,
       c.relhastriggers            AS hastriggers,
       CASE
           WHEN pg_check_authid(po.creator) THEN pg_get_userbyid(po.creator)
           ELSE NULL::name
           END                     AS tablecreator,
       po.ctime                    AS created,
       po.mtime                    AS last_ddl_time
FROM pg_class c
         LEFT JOIN pg_namespace n ON n.oid = c.relnamespace
         LEFT JOIN pg_tablespace t ON t.oid = c.reltablespace
         LEFT JOIN pg_object po ON po.object_oid = c.oid AND po.object_type = 'r'::"char"
WHERE c.relkind = 'r'::"char";

alter table pg_tables
    owner to omm;

