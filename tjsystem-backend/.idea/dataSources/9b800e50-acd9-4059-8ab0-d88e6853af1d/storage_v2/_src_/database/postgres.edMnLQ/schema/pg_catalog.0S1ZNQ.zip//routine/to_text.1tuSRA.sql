create function to_text(timestamp without time zone) returns text
    immutable
    strict
    language sql
as
$$
select CAST(pg_catalog.timestamp_out($1) AS VARCHAR2)
$$;

alter function to_text(timestamp) owner to omm;

