create function to_clob(text) returns clob
    immutable
    strict
    language sql
as
$$
select $1
$$;

alter function to_clob(text) owner to omm;

