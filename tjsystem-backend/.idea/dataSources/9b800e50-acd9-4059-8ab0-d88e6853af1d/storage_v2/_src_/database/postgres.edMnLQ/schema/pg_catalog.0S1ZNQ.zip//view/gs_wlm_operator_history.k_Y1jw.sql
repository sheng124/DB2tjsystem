create view gs_wlm_operator_history
            (queryid, pid, plan_node_id, plan_node_name, start_time, duration, query_dop, estimated_rows,
             tuple_processed, min_peak_memory, max_peak_memory, average_peak_memory, memory_skew_percent,
             min_spill_size, max_spill_size, average_spill_size, spill_skew_percent, min_cpu_time, max_cpu_time,
             total_cpu_time, cpu_skew_percent, warning)
as
SELECT *
FROM pg_stat_get_wlm_operator_info(0::oid) pg_stat_get_wlm_operator_info(queryid, pid, plan_node_id, plan_node_name,
                                                                         start_time, duration, query_dop,
                                                                         estimated_rows, tuple_processed,
                                                                         min_peak_memory, max_peak_memory,
                                                                         average_peak_memory, memory_skew_percent,
                                                                         min_spill_size, max_spill_size,
                                                                         average_spill_size, spill_skew_percent,
                                                                         min_cpu_time, max_cpu_time, total_cpu_time,
                                                                         cpu_skew_percent, warning);

alter table gs_wlm_operator_history
    owner to omm;

