create view pg_thread_wait_status
            (node_name, db_name, thread_name, query_id, tid, sessionid, lwtid, psessionid, tlevel, smpid, wait_status,
             wait_event, locktag, lockmode, block_sessionid, global_sessionid)
as
SELECT *
FROM pg_stat_get_status(NULL::bigint) pg_stat_get_status(node_name, db_name, thread_name, query_id, tid, sessionid,
                                                         lwtid, psessionid, tlevel, smpid, wait_status, wait_event,
                                                         locktag, lockmode, block_sessionid, global_sessionid);

alter table pg_thread_wait_status
    owner to omm;

