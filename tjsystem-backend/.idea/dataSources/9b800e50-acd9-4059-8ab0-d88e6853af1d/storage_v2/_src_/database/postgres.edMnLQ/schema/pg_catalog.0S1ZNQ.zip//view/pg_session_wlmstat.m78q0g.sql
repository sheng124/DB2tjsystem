create view pg_session_wlmstat
            (datid, datname, threadid, sessionid, processid, usesysid, appname, usename, priority, attribute,
             block_time, elapsed_time, total_cpu_time, cpu_skew_percent, statement_mem, active_points, dop_value,
             control_group, status, enqueue, resource_pool, query, is_plana, node_group)
as
SELECT s.datid,
       d.datname,
       s.threadid,
       s.sessionid,
       s.threadpid      AS processid,
       s.usesysid,
       s.appname,
       u.rolname        AS usename,
       s.priority,
       s.attribute,
       s.block_time,
       s.elapsed_time,
       s.total_cpu_time,
       s.skew_percent   AS cpu_skew_percent,
       s.statement_mem,
       s.active_points,
       s.dop_value,
       s.current_cgroup AS control_group,
       s.current_status AS status,
       s.enqueue_state  AS enqueue,
       CASE
           WHEN t.session_respool = 'unknown'::name THEN u.rolrespool
           ELSE t.session_respool
           END          AS resource_pool,
       s.query,
       s.is_plana,
       s.node_group
FROM pg_database d,
     pg_stat_get_session_wlmstat(NULL::integer) s(datid, threadid, sessionid, threadpid, usesysid, appname, query,
                                                  priority, block_time, elapsed_time, total_cpu_time, skew_percent,
                                                  statement_mem, active_points, dop_value, current_cgroup,
                                                  current_status, enqueue_state, attribute, is_plana, node_group,
                                                  srespool),
     pg_authid u,
     gs_wlm_session_respool(0::bigint) t(datid, threadid, sessionid, threadpid, usesysid, cgroup, session_respool)
WHERE s.datid = d.oid
  AND s.usesysid = u.oid
  AND t.sessionid = s.sessionid;

alter table pg_session_wlmstat
    owner to omm;

