create view pg_statio_sys_sequences(relid, schemaname, relname, blks_read, blks_hit) as
SELECT *
FROM pg_statio_all_sequences
WHERE (pg_statio_all_sequences.schemaname = ANY (ARRAY ['pg_catalog'::name, 'information_schema'::name]))
   OR pg_statio_all_sequences.schemaname ~ '^pg_toast'::text;

alter table pg_statio_sys_sequences
    owner to omm;

