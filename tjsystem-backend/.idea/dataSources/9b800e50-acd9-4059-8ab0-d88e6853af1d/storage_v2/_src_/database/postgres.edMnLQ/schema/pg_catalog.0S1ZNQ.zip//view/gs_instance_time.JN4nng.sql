create view gs_instance_time(stat_id, stat_name, value) as
SELECT *
FROM pv_instance_time() pv_instance_time(stat_id, stat_name, value);

alter table gs_instance_time
    owner to omm;

