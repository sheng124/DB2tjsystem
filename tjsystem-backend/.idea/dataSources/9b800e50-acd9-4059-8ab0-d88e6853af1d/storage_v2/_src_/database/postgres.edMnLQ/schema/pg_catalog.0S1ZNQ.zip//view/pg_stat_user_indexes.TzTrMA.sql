create view pg_stat_user_indexes
            (relid, indexrelid, schemaname, relname, indexrelname, idx_scan, idx_tup_read, idx_tup_fetch) as
SELECT *
FROM pg_stat_all_indexes
WHERE (pg_stat_all_indexes.schemaname <> ALL (ARRAY ['pg_catalog'::name, 'information_schema'::name]))
  AND pg_stat_all_indexes.schemaname !~ '^pg_toast'::text;

alter table pg_stat_user_indexes
    owner to omm;

