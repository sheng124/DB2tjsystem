create function get_local_toast_relation(OUT shemaname name, OUT relname name, OUT toastname name) returns SETOF record
    language plpgsql
as
$$
DECLARE
  query_str text;
  BEGIN
    query_str := '
    SELECT 
        N.nspname as shemaname,
        S.relname as relname,
        T.relname as toastname
    FROM pg_class S JOIN pg_namespace N ON N.oid = S.relnamespace
        LEFT JOIN pg_class T on T.oid=S.reltoastrelid
        WHERE T.relname is not NULL';
    return query execute query_str;
  END;
$$;

alter function get_local_toast_relation(out name, out name, out name) owner to omm;

