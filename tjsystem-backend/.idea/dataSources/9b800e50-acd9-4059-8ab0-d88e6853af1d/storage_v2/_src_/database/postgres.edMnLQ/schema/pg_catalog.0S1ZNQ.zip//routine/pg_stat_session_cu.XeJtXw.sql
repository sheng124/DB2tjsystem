create function pg_stat_session_cu(OUT mem_hit integer, OUT hdd_sync_read integer, OUT hdd_asyn_read integer) returns SETOF record
    language plpgsql
as
$$
DECLARE
	stat_result record;
	query_str text;
	statname text;
	BEGIN
		query_str := 'select statname, pg_catalog.sum(value) as value from gs_session_stat group by statname;';
		FOR stat_result IN EXECUTE(query_str) LOOP
			statname := stat_result.statname;
			IF statname = 'n_cu_mem_hit' THEN
				mem_hit := stat_result.value;
			ELSIF statname = 'n_cu_hdd_sync_read' THEN
				hdd_sync_read := stat_result.value;
			ELSIF statname = 'n_cu_hdd_asyn_read' THEN
				hdd_asyn_read := stat_result.value;
			END IF;
		END LOOP;
		return next;
	END;
$$;

alter function pg_stat_session_cu(out integer, out integer, out integer) owner to omm;

