create view gs_auditing_privilege (polname, pol_type, polenabled, access_type, label_name, priv_object, filter_name) as
SELECT DISTINCT p.polname,
                'privilege'::text                                    AS pol_type,
                p.polenabled,
                priv.privilegetype                                   AS access_type,
                priv.labelname                                       AS label_name,
                CASE l.fqdntype
                    WHEN 'column'::name THEN (((((l.fqdntype::text || ':'::text) || l.schemaname::text) || '.'::text) ||
                                               l.fqdnname::text) || '.'::text) || l.columnname::text
                    WHEN 'table'::name THEN (((l.fqdntype::text || ':'::text) || l.schemaname::text) || '.'::text) ||
                                            l.fqdnname::text
                    WHEN 'view'::name THEN (((l.fqdntype::text || ':'::text) || l.schemaname::text) || '.'::text) ||
                                           l.fqdnname::text
                    WHEN 'schema'::name THEN (l.fqdntype::text || ':'::text) || l.schemaname::text
                    WHEN 'function'::name THEN (((l.fqdntype::text || ':'::text) || l.schemaname::text) || '.'::text) ||
                                               l.fqdnname::text
                    WHEN 'label'::name THEN (l.fqdntype::text || ':'::text) || l.columnname::text
                    ELSE (l.fqdntype::text || ':'::text) || NULL::text
                    END                                              AS priv_object,
                (SELECT gs_auditing_policy_filters.logicaloperator
                 FROM gs_auditing_policy_filters
                 WHERE p.oid = gs_auditing_policy_filters.policyoid) AS filter_name
FROM gs_auditing_policy p
         LEFT JOIN gs_auditing_policy_privileges priv ON priv.policyoid = p.oid
         LEFT JOIN gs_labels l ON priv.labelname = l.labelname
WHERE length(priv.privilegetype::text) > 0
ORDER BY p.polname, p.polenabled;

alter table gs_auditing_privilege
    owner to omm;

