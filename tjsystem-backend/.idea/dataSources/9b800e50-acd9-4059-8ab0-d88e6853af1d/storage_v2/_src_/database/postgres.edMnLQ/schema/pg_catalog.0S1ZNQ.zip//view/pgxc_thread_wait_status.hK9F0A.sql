create view pgxc_thread_wait_status
            (node_name, db_name, thread_name, query_id, tid, sessionid, lwtid, psessionid, tlevel, smpid, wait_status,
             wait_event, locktag, lockmode, block_sessionid, global_sessionid)
as
SELECT *
FROM pgxc_get_thread_wait_status() pgxc_get_thread_wait_status(node_name, db_name, thread_name, query_id, tid,
                                                               sessionid, lwtid, psessionid, tlevel, smpid, wait_status,
                                                               wait_event, locktag, lockmode, block_sessionid,
                                                               global_sessionid);

alter table pgxc_thread_wait_status
    owner to omm;

