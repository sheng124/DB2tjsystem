create function to_text(numeric) returns text
    immutable
    strict
    language sql
as
$$
SELECT CAST(pg_catalog.numeric_out($1) AS VARCHAR)
$$;

alter function to_text(numeric) owner to omm;

