create function alldigitsmasking(col text, letter character DEFAULT '0'::bpchar) returns text
    language plpgsql
as
$$
begin
    return pg_catalog.REGEXP_REPLACE(col, '[\d+]', letter, 'g');
end;
$$;

alter function alldigitsmasking(text, char) owner to omm;

