create view gs_comm_proxy_thread_status
            ("ProxyThreadId", "ProxyCpuAffinity", "ThreadStartTime", "RxPckNums", "TxPckNums", "RxPcks", "TxPcks") as
SELECT DISTINCT *
FROM gs_comm_proxy_thread_status() gs_comm_proxy_thread_status("ProxyThreadId", "ProxyCpuAffinity", "ThreadStartTime",
                                                               "RxPckNums", "TxPckNums", "RxPcks", "TxPcks");

alter table gs_comm_proxy_thread_status
    owner to omm;

