create function substr(text, bigint) returns text
    immutable
    strict
    language sql
as
$$
select pg_catalog.SUBSTR($1, $2::INT4);
$$;

alter function substr(text, bigint) owner to omm;

