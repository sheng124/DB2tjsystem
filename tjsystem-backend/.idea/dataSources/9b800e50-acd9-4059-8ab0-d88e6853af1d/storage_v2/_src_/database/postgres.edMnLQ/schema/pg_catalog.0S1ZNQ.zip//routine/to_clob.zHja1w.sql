create function to_clob(character varying) returns clob
    immutable
    strict
    language sql
as
$$
select CAST($1 AS TEXT)
$$;

alter function to_clob(varchar) owner to omm;

