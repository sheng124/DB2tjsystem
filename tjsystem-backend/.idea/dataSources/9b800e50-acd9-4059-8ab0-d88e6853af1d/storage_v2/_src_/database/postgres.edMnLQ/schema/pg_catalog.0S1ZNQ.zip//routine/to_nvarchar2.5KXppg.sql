create function to_nvarchar2(timestamp without time zone) returns nvarchar2
    immutable
    strict
    language sql
as
$$
select CAST(pg_catalog.timestamp_out($1) AS NVARCHAR2)
$$;

alter function to_nvarchar2(timestamp) owner to omm;

