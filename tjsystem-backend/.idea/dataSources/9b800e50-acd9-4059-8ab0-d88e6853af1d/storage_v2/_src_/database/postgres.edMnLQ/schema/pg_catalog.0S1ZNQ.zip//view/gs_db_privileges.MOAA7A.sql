create view gs_db_privileges(rolename, privilege_type, admin_option) as
SELECT pg_get_userbyid(gs_db_privilege.roleid) AS rolename,
       gs_db_privilege.privilege_type,
       CASE
           WHEN gs_db_privilege.admin_option THEN 'yes'::text
           ELSE 'no'::text
           END                                 AS admin_option
FROM gs_db_privilege;

alter table gs_db_privileges
    owner to omm;

