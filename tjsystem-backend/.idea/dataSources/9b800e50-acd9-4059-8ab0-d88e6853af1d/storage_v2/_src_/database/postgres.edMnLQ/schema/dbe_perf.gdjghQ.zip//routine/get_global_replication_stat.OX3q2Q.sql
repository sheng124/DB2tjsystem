create function get_global_replication_stat(OUT node_name name, OUT pid bigint, OUT usesysid oid, OUT usename name, OUT application_name text, OUT client_addr inet, OUT client_hostname text, OUT client_port integer, OUT backend_start timestamp with time zone, OUT state text, OUT sender_sent_location text, OUT receiver_write_location text, OUT receiver_flush_location text, OUT receiver_replay_location text, OUT sync_priority integer, OUT sync_state text) returns SETOF record
    language plpgsql
as
$$
DECLARE
  row_data dbe_perf.replication_stat%rowtype;
  row_name record;
  query_str text;
  query_str_nodes text;
  BEGIN
    --Get all the node names
    query_str_nodes := 'select * from dbe_perf.node_name';
    FOR row_name IN EXECUTE(query_str_nodes) LOOP
      query_str := 'SELECT * FROM dbe_perf.replication_stat';
      FOR row_data IN EXECUTE(query_str) LOOP
        node_name := row_name.node_name;
        pid := row_data.pid;
        usesysid := row_data.usesysid;
        usename := row_data.usename;
        client_addr := row_data.client_addr;
        client_hostname := row_data.client_hostname;
        client_port := row_data.client_port;
        state := row_data.state;
        sender_sent_location := row_data.sender_sent_location;
        receiver_write_location := row_data.receiver_write_location;
        receiver_flush_location := row_data.receiver_flush_location;
        receiver_replay_location := row_data.receiver_replay_location;
        sync_priority := row_data.sync_priority;
        sync_state := row_data.sync_state;
        return next;
      END LOOP;
    END LOOP;
    return;
  END;
$$;

alter function get_global_replication_stat(out name, out bigint, out oid, out name, out text, out inet, out text, out integer, out timestamp with time zone, out text, out text, out text, out text, out text, out integer, out text) owner to omm;

