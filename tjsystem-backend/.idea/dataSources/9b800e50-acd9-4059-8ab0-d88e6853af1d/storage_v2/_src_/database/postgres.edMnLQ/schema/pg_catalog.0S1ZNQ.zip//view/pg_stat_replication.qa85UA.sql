create view pg_stat_replication
            (pid, usesysid, usename, application_name, client_addr, client_hostname, client_port, backend_start, state,
             sender_sent_location, receiver_write_location, receiver_flush_location, receiver_replay_location,
             sync_priority, sync_state)
as
SELECT s.pid,
       s.usesysid,
       u.rolname AS usename,
       s.application_name,
       s.client_addr,
       s.client_hostname,
       s.client_port,
       s.backend_start,
       w.state,
       w.sender_sent_location,
       w.receiver_write_location,
       w.receiver_flush_location,
       w.receiver_replay_location,
       w.sync_priority,
       w.sync_state
FROM pg_stat_get_activity(NULL::bigint) s(datid, pid, sessionid, usesysid, application_name, state, query, waiting,
                                          xact_start, query_start, backend_start, state_change, client_addr,
                                          client_hostname, client_port, enqueue, query_id, srespool, global_sessionid,
                                          unique_sql_id, trace_id),
     pg_authid u,
     pg_stat_get_wal_senders() w(pid, sender_pid, local_role, peer_role, peer_state, state, catchup_start, catchup_end,
                                 sender_sent_location, sender_write_location, sender_flush_location,
                                 sender_replay_location, receiver_received_location, receiver_write_location,
                                 receiver_flush_location, receiver_replay_location, sync_percent, sync_state,
                                 sync_priority, sync_most_available, channel)
WHERE s.usesysid = u.oid
  AND s.pid = w.pid;

alter table pg_stat_replication
    owner to omm;

