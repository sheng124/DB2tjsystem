create function to_nvarchar2(real) returns nvarchar2
    immutable
    strict
    language sql
as
$$
select CAST(pg_catalog.float4out($1) AS NVARCHAR2)
$$;

alter function to_nvarchar2(real) owner to omm;

