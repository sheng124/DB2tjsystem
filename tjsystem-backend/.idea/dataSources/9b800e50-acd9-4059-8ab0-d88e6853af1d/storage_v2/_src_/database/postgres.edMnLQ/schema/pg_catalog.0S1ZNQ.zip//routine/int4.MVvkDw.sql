create function int4(text) returns integer
    immutable
    strict
    language sql
as
$$
select cast(pg_catalog.to_number($1) as int4)
$$;

alter function int4(text) owner to omm;

