create function float4(text) returns real
    immutable
    strict
    language sql
as
$$
select cast(pg_catalog.to_number($1) as float4)
$$;

alter function float4(text) owner to omm;

