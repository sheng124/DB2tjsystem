create function to_nvarchar2(smallint) returns nvarchar2
    immutable
    strict
    language sql
as
$$
select CAST(pg_catalog.int2out($1) AS NVARCHAR2)
$$;

alter function to_nvarchar2(smallint) owner to omm;

