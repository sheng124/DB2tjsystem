create view pg_rlspolicies (schemaname, tablename, policyname, policypermissive, policyroles, policycmd, policyqual) as
SELECT n.nspname                              AS schemaname,
       c.relname                              AS tablename,
       pol.polname                            AS policyname,
       CASE
           WHEN pol.polpermissive THEN 'PERMISSIVE'::text
           ELSE 'RESTRICTIVE'::text
           END                                AS policypermissive,
       CASE
           WHEN pol.polroles = '{0}'::oid[] THEN string_to_array('public'::text, ' '::text)::name[]
           ELSE ARRAY(SELECT pg_authid.rolname
                      FROM pg_authid
                      WHERE pg_authid.oid = ANY (pol.polroles)
                      ORDER BY pg_authid.rolname)
           END                                AS policyroles,
       CASE pol.polcmd
           WHEN 'r'::"char" THEN 'SELECT'::text
           WHEN 'a'::"char" THEN 'INSERT'::text
           WHEN 'w'::"char" THEN 'UPDATE'::text
           WHEN 'd'::"char" THEN 'DELETE'::text
           WHEN '*'::"char" THEN 'ALL'::text
           ELSE NULL::text
           END                                AS policycmd,
       pg_get_expr(pol.polqual, pol.polrelid) AS policyqual
FROM pg_rlspolicy pol
         JOIN pg_class c ON c.oid = pol.polrelid
         LEFT JOIN pg_namespace n ON n.oid = c.relnamespace
WHERE c.relowner = ((SELECT pg_authid.oid
                     FROM pg_authid
                     WHERE pg_authid.rolname = "current_user"()))
   OR (SELECT pg_authid.rolsystemadmin
       FROM pg_authid
       WHERE pg_authid.rolname = "current_user"());

alter table pg_rlspolicies
    owner to omm;

