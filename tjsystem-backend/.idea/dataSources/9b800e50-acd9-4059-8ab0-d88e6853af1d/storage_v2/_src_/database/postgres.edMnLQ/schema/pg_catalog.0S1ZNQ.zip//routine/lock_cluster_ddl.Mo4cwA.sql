create function lock_cluster_ddl() returns boolean
    language plpgsql
as
$$
DECLARE                                                                                                   
	databse_name record; 
	lock_str text;
	query_database_oid text;
	lock_result  boolean = false;
	return_result  bool = true;
	BEGIN                                                                   
		query_database_oid := 'SELECT datname FROM pg_database WHERE datallowconn = true order by datname';
		for databse_name in EXECUTE(query_database_oid) LOOP
			lock_str = pg_catalog.format('SELECT * FROM pg_catalog.pgxc_lock_for_sp_database(''%s'')', databse_name.datname);
			begin
				EXECUTE(lock_str) into lock_result;
				if lock_result = 'f' then
					return_result = false;
					return return_result; 
				end if;
			end;
		end loop;
		return return_result;                                                   
	END;
$$;

alter function lock_cluster_ddl() owner to omm;

