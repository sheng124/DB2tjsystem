create function get_global_stat_bad_block(OUT node_name text, OUT databaseid integer, OUT tablespaceid integer, OUT relfilenode integer, OUT forknum integer, OUT error_count integer, OUT first_time timestamp with time zone, OUT last_time timestamp with time zone) returns SETOF record
    language plpgsql
as
$$
DECLARE
  row_name record;
  each_node_out record;
  query_str text;
  query_str_nodes text;
  BEGIN
    query_str_nodes := 'select * from dbe_perf.node_name';
    FOR row_name IN EXECUTE(query_str_nodes) LOOP
      query_str := 'SELECT * FROM dbe_perf.stat_bad_block';
      FOR each_node_out IN EXECUTE(query_str) LOOP
        node_name := row_name.node_name;
        databaseid := each_node_out.databaseid;
        tablespaceid := each_node_out.tablespaceid;
        relfilenode := each_node_out.relfilenode;
        forknum := each_node_out.forknum;
        error_count := each_node_out.error_count;
        first_time := each_node_out.first_time;
        last_time := each_node_out.last_time;
        return next;
      END LOOP;
    END LOOP;
    return;
  END;
$$;

alter function get_global_stat_bad_block(out text, out integer, out integer, out integer, out integer, out integer, out timestamp with time zone, out timestamp with time zone) owner to omm;

