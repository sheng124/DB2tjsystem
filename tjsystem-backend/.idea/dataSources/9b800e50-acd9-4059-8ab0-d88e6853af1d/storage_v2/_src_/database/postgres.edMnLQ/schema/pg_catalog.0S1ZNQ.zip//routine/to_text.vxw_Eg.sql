create function to_text(bigint) returns text
    immutable
    strict
    language sql
as
$$
select CAST(pg_catalog.int8out($1) AS VARCHAR)
$$;

alter function to_text(bigint) owner to omm;

