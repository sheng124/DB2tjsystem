create view pg_get_senders_catchup_time (pid, lwpid, local_role, peer_role, state, type, catchup_start, catchup_end) as
SELECT w.pid,
       w.sender_pid AS lwpid,
       w.local_role,
       w.peer_role,
       w.state,
       'Wal'::text  AS type,
       w.catchup_start,
       w.catchup_end
FROM pg_stat_get_wal_senders() w(pid, sender_pid, local_role, peer_role, peer_state, state, catchup_start, catchup_end,
                                 sender_sent_location, sender_write_location, sender_flush_location,
                                 sender_replay_location, receiver_received_location, receiver_write_location,
                                 receiver_flush_location, receiver_replay_location, sync_percent, sync_state,
                                 sync_priority, sync_most_available, channel)
UNION ALL
SELECT d.pid,
       d.sender_pid AS lwpid,
       d.local_role,
       d.peer_role,
       d.state,
       'Data'::text AS type,
       d.catchup_start,
       d.catchup_end
FROM pg_stat_get_data_senders() d(pid, sender_pid, local_role, peer_role, state, catchup_start, catchup_end, queue_size,
                                  queue_lower_tail, queue_header, queue_upper_tail, send_position, receive_position);

alter table pg_get_senders_catchup_time
    owner to omm;

