create function to_number(text) returns numeric
    immutable
    strict
    language sql
as
$$
select pg_catalog.numeric_in(pg_catalog.textout($1), 0::Oid, -1)
$$;

alter function to_number(text) owner to omm;

