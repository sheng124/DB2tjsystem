create view gs_masking (polname, polenabled, maskaction, labelname, masking_object, filter_name) as
SELECT DISTINCT p.polname,
                p.polenabled,
                a.actiontype                                        AS maskaction,
                a.actlabelname                                      AS labelname,
                CASE l.fqdntype
                    WHEN 'column'::name THEN (((((l.fqdntype::text || ':'::text) || l.schemaname::text) || '.'::text) ||
                                               l.fqdnname::text) || '.'::text) || l.columnname::text
                    WHEN 'table'::name THEN (((l.fqdntype::text || ':'::text) || l.schemaname::text) || '.'::text) ||
                                            l.fqdnname::text
                    WHEN 'view'::name THEN (((l.fqdntype::text || ':'::text) || l.schemaname::text) || '.'::text) ||
                                           l.fqdnname::text
                    WHEN 'schema'::name THEN (l.fqdntype::text || ':'::text) || l.schemaname::text
                    WHEN 'function'::name THEN (((l.fqdntype::text || ':'::text) || l.schemaname::text) || '.'::text) ||
                                               l.fqdnname::text
                    WHEN 'label'::name THEN (l.fqdntype::text || ':'::text) || l.columnname::text
                    ELSE (l.fqdntype::text || ':'::text) || NULL::text
                    END                                             AS masking_object,
                (SELECT gs_masking_policy_filters.logicaloperator
                 FROM gs_masking_policy_filters
                 WHERE p.oid = gs_masking_policy_filters.policyoid) AS filter_name
FROM gs_masking_policy p
         JOIN gs_masking_policy_actions a ON p.oid = a.policyoid
         JOIN gs_labels l ON a.actlabelname = l.labelname
WHERE l.fqdntype = 'column'::name
   OR l.fqdntype = 'table'::name
ORDER BY p.polname;

alter table gs_masking
    owner to omm;

