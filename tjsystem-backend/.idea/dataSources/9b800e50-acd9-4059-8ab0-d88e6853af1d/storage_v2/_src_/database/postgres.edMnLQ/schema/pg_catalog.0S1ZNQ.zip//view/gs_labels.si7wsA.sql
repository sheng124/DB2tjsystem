create view gs_labels(labelname, labeltype, fqdntype, schemaname, fqdnname, columnname) as
SELECT gs_policy_label.labelname,
       gs_policy_label.labeltype,
       gs_policy_label.fqdntype,
       CASE gs_policy_label.fqdntype
           WHEN 'column'::name THEN (SELECT pg_namespace.nspname
                                     FROM pg_namespace
                                     WHERE pg_namespace.oid = gs_policy_label.fqdnnamespace)
           WHEN 'table'::name THEN (SELECT pg_namespace.nspname
                                    FROM pg_namespace
                                    WHERE pg_namespace.oid = gs_policy_label.fqdnnamespace)
           WHEN 'view'::name THEN (SELECT pg_namespace.nspname
                                   FROM pg_namespace
                                   WHERE pg_namespace.oid = gs_policy_label.fqdnnamespace)
           WHEN 'schema'::name THEN (SELECT pg_namespace.nspname
                                     FROM pg_namespace
                                     WHERE pg_namespace.oid = gs_policy_label.fqdnnamespace)
           WHEN 'function'::name THEN (SELECT pg_namespace.nspname
                                       FROM pg_namespace
                                       WHERE pg_namespace.oid = gs_policy_label.fqdnnamespace)
           ELSE NULL::name
           END AS schemaname,
       CASE gs_policy_label.fqdntype
           WHEN 'column'::name THEN (SELECT pg_class.relname
                                     FROM pg_class
                                     WHERE pg_class.oid = gs_policy_label.fqdnid)
           WHEN 'table'::name THEN (SELECT pg_class.relname
                                    FROM pg_class
                                    WHERE pg_class.oid = gs_policy_label.fqdnid)
           WHEN 'view'::name THEN (SELECT pg_class.relname
                                   FROM pg_class
                                   WHERE pg_class.oid = gs_policy_label.fqdnid)
           WHEN 'function'::name THEN (SELECT pg_proc.proname
                                       FROM pg_proc
                                       WHERE pg_proc.oid = gs_policy_label.fqdnid)
           WHEN 'label'::name THEN gs_policy_label.relcolumn
           ELSE NULL::name
           END AS fqdnname,
       CASE gs_policy_label.fqdntype
           WHEN 'column'::name THEN gs_policy_label.relcolumn
           ELSE NULL::name
           END AS columnname
FROM gs_policy_label
WHERE length(gs_policy_label.fqdntype::text) > 0
ORDER BY gs_policy_label.labelname, gs_policy_label.labeltype, gs_policy_label.fqdntype;

alter table gs_labels
    owner to omm;

