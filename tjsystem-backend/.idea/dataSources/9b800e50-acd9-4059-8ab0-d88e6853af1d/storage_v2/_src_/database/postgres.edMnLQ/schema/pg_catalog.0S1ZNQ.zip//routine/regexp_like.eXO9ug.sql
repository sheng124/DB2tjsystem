create function regexp_like(text, text, text) returns boolean
    language plpgsql
as
$$
declare
	regex_char varchar(1);
begin
	for i in 1..pg_catalog.length($3) loop
		regex_char := pg_catalog.substr($3,i,1);
		if regex_char <> 'i' and  regex_char <> 'm' and  regex_char <> 'c' then
			raise info 'illegal argument for function';
			return false;
		end if;
	end loop;
	case pg_catalog.right($3, 1)
		when 'i' then return $1 ~* $2;
		when 'c' then return $1 ~ $2;
		when 'm' then return pg_catalog.regex_like_m($1,$2);
	end case;
end;
$$;

alter function regexp_like(text, text, text) owner to omm;

