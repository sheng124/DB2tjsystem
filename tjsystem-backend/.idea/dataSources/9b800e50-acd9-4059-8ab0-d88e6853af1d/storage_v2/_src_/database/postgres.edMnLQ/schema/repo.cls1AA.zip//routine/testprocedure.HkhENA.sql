create function testprocedure(t_account_name character varying, t_pwd character varying, OUT t_id bigint) returns void
    language plpgsql
as
$$
BEGIN
    SELECT ID INTO t_ID FROM "user" WHERE account_name = t_account_name AND pwd = t_pwd;
END;
$$;

alter function testprocedure(varchar, varchar, out bigint) owner to test;

