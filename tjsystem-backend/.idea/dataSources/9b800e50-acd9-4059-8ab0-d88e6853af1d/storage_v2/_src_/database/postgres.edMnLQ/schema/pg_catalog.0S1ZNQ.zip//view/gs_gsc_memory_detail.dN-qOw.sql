create view gs_gsc_memory_detail(db_id, totalsize, freesize, usedsize) as
SELECT a.db_id,
       sum(a.totalsize) AS totalsize,
       sum(a.freesize)  AS freesize,
       sum(a.usedsize)  AS usedsize
FROM (SELECT CASE
                 WHEN pg_shared_memory_detail.contextname ~~ '%GlobalSysDBCacheEntryMemCxt%'::text
                     THEN "substring"(pg_shared_memory_detail.contextname, 29)
                 ELSE "substring"(pg_shared_memory_detail.parent, 29)
                 END AS db_id,
             pg_shared_memory_detail.totalsize,
             pg_shared_memory_detail.freesize,
             pg_shared_memory_detail.usedsize
      FROM pg_shared_memory_detail() pg_shared_memory_detail(contextname, level, parent, totalsize, freesize, usedsize)
      WHERE pg_shared_memory_detail.contextname ~~ '%GlobalSysDBCacheEntryMemCxt%'::text
         OR pg_shared_memory_detail.parent ~~ '%GlobalSysDBCacheEntryMemCxt%'::text) a
GROUP BY a.db_id;

alter table gs_gsc_memory_detail
    owner to omm;

