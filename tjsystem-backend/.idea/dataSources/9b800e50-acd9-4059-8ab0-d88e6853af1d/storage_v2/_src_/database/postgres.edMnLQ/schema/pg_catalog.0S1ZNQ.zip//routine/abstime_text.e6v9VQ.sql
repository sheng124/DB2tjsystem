create function abstime_text(abstime) returns text
    immutable
    strict
    language sql
as
$$
SELECT CAST(pg_catalog.abstimeout($1) AS text)
$$;

alter function abstime_text(abstime) owner to omm;

