create function to_integer(character) returns integer
    immutable
    strict
    language sql
as
$$
SELECT pg_catalog.int4in(pg_catalog.bpcharout($1))
$$;

alter function to_integer(char) owner to omm;

