create view pg_wlm_statistics
            (statement, block_time, elapsed_time, total_cpu_time, qualification_time, cpu_skew_percent, control_group,
             status, action)
as
SELECT pg_stat_get_wlm_statistics.statement,
       pg_stat_get_wlm_statistics.block_time,
       pg_stat_get_wlm_statistics.elapsed_time,
       pg_stat_get_wlm_statistics.total_cpu_time,
       pg_stat_get_wlm_statistics.qualification_time,
       pg_stat_get_wlm_statistics.skew_percent AS cpu_skew_percent,
       pg_stat_get_wlm_statistics.control_group,
       pg_stat_get_wlm_statistics.status,
       pg_stat_get_wlm_statistics.action
FROM pg_stat_get_wlm_statistics(NULL::integer) pg_stat_get_wlm_statistics(statement, block_time, elapsed_time,
                                                                          total_cpu_time, qualification_time,
                                                                          skew_percent, control_group, status, action);

alter table pg_wlm_statistics
    owner to omm;

