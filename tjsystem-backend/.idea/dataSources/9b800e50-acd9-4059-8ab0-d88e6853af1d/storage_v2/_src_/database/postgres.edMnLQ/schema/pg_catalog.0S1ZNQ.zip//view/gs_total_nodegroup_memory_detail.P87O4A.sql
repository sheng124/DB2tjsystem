create view gs_total_nodegroup_memory_detail(ngname, memorytype, memorymbytes) as
SELECT *
FROM gs_total_nodegroup_memory_detail() gs_total_nodegroup_memory_detail(ngname, memorytype, memorymbytes);

alter table gs_total_nodegroup_memory_detail
    owner to omm;

