create view gs_redo_stat(phywrts, phyblkwrt, writetim, avgiotim, lstiotim, miniotim, maxiowtm) as
SELECT *
FROM pg_stat_get_redo_stat() pg_stat_get_redo_stat(phywrts, phyblkwrt, writetim, avgiotim, lstiotim, miniotim, maxiowtm);

alter table gs_redo_stat
    owner to omm;

