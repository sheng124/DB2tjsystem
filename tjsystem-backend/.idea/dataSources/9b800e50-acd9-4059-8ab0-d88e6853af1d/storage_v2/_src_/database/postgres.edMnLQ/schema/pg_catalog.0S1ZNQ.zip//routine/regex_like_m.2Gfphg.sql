create function regex_like_m(text, text) returns boolean
    language plpgsql
as
$$
declare
        source_line integer := 1;
        regex_line integer := 1;
        position integer := 1;
        i integer := 1;
        j integer := 1;
        regex_temp text := '';
        flag boolean := false;
        TYPE array_text is varray(1024) of text;
        source_array array_text := array_text();
        regex_array array_text := array_text();
begin
	if pg_catalog.left($2,1) <> '^' and pg_catalog.right($2,1) <> '$' then
		return $1 ~ $2;
	end if;
	--source string to source_array
	for i in 1..pg_catalog.length($1) loop
		if pg_catalog.substr($1,i,1) ~ '\n' then
			if position = i then
				source_array(source_line) := '\n';
			else
				source_array(source_line) := pg_catalog.substr($1,position,i - position);
			end if;
			position := i + 1;
			source_line := source_line + 1;
		end if;
	end loop;
	if position <= pg_catalog.length($1) or position = 1 then
		source_array(source_line) := pg_catalog.substr($1,position);
	else 
		if position > pg_catalog.length($1) then
			source_line := source_line - 1;
		end if;
	end if;
		
	--regexp string to regex_array
	position := 1;
	for i in 1..pg_catalog.length($2) loop
		if pg_catalog.substr($2,i,1) ~ '\n' then
			if position = i then
				regex_array(regex_line) := '\n';
			else
				regex_array(regex_line) := pg_catalog.substr($2,position,i - position);
			end if;
			position := i + 1;
			regex_line := regex_line + 1;
		end if;
	end loop;
		if position <= pg_catalog.length($2) or position = 1 then
			regex_array(regex_line) := pg_catalog.substr($2,position);
		else
			if position > pg_catalog.length($2) then
				regex_line := regex_line - 1;
			end if;
		end if;
	
	--start
	for i in 1..source_line loop
		if source_array[i] ~ regex_array[j] then
			flag := true;
			j := j + 1;
			while j <= regex_line loop
				i := i + 1;
				if source_array[i] ~ regex_array[j] then
					j := j + 1;
				else
					flag := false;
					exit;
				end if;
			end loop;
			exit;
		end if;
	end loop;
	if pg_catalog.left($2,1) = '^' then
		regex_temp := pg_catalog.substr($2,2);
	else
		regex_temp := $2;
	end if;
	if pg_catalog.right($2,1) = '$' then
		regex_temp := pg_catalog.substr(regex_temp,1,pg_catalog.length(regex_temp)-1);
	end if;
	if flag then
 		flag := $1 ~ regex_temp;
 	end if;
	return flag;
end;
$$;

alter function regex_like_m(text, text) owner to omm;

