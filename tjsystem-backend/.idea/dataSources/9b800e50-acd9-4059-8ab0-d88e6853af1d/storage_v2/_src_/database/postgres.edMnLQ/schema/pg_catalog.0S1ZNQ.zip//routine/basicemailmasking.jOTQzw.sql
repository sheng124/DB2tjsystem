create function basicemailmasking(col text, letter character DEFAULT 'x'::bpchar) returns text
    language plpgsql
as
$$
declare 
    pos INTEGER := position('@' in col);
begin
    return CASE WHEN pos > 1 THEN
    pg_catalog.repeat(letter, pos - 1) || pg_catalog.substring(col, pos, pg_catalog.length(col) - pos +1)
    ELSE
        col
    end;
end;
$$;

alter function basicemailmasking(text, char) owner to omm;

