create view pg_total_user_resource_info
            (username, used_memory, total_memory, used_cpu, total_cpu, used_space, total_space, used_temp_space,
             total_temp_space, used_spill_space, total_spill_space, read_kbytes, write_kbytes, read_counts,
             write_counts, read_speed, write_speed)
as
SELECT s.usename AS username,
       t.used_memory,
       t.total_memory,
       t.used_cpu,
       t.total_cpu,
       t.used_space,
       t.total_space,
       t.used_temp_space,
       t.total_temp_space,
       t.used_spill_space,
       t.total_spill_space,
       t.read_kbytes,
       t.write_kbytes,
       t.read_counts,
       t.write_counts,
       t.read_speed,
       t.write_speed
FROM pg_user s,
     pg_total_user_resource_info_oid t
WHERE s.usesysid = t.userid;

alter table pg_total_user_resource_info
    owner to omm;

