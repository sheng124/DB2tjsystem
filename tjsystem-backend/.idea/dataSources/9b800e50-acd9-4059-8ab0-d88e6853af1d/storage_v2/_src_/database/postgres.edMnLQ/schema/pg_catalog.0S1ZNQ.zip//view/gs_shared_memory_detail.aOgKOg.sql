create view gs_shared_memory_detail(contextname, level, parent, totalsize, freesize, usedsize) as
SELECT *
FROM pg_shared_memory_detail() pg_shared_memory_detail(contextname, level, parent, totalsize, freesize, usedsize);

alter table gs_shared_memory_detail
    owner to omm;

