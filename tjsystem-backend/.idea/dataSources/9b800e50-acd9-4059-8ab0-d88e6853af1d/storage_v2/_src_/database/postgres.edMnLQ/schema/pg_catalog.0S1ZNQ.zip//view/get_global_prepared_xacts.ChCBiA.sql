create view get_global_prepared_xacts(transaction, gid, prepared, owner, database, node_name) as
SELECT p.transaction,
       p.gid,
       p.prepared,
       u.rolname AS owner,
       d.datname AS database,
       p.node_name
FROM get_local_prepared_xact() p(transaction, gid, prepared, ownerid, dbid, node_name)
         LEFT JOIN pg_authid u ON p.ownerid = u.oid
         LEFT JOIN pg_database d ON p.dbid = d.oid
UNION ALL
SELECT *
FROM get_remote_prepared_xacts() get_remote_prepared_xacts(transaction, gid, prepared, owner, database, node_name);

alter table get_global_prepared_xacts
    owner to omm;

