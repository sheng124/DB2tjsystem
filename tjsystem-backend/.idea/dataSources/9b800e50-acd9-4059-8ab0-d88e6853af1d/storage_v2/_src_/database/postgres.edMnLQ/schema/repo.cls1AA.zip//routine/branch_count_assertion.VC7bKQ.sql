create function branch_count_assertion() returns trigger
    language plpgsql
as
$$
BEGIN
    IF (SELECT COUNT(*) FROM branch WHERE repo_id = NEW.repo_id) >= 5 THEN
        RAISE EXCEPTION 'The count of branch is above 5.';
    END IF;
    RETURN NEW;
END;
$$;

alter function branch_count_assertion() owner to test;

