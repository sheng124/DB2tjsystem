create function randommasking(col text) returns text
    language plpgsql
as
$$
begin
    return pg_catalog.left(pg_catalog.MD5(pg_catalog.random()::text), pg_catalog.length(col));
end;
$$;

alter function randommasking(text) owner to omm;

