create function to_char(smallint) returns character varying
    immutable
    strict
    language sql
as
$$
SELECT CAST(pg_catalog.int2out($1) AS VARCHAR2)
$$;

alter function to_char(smallint) owner to omm;

