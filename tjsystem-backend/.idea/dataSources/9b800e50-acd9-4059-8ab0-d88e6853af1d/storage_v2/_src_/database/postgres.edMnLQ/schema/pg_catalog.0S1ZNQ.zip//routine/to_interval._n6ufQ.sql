create function to_interval(character) returns interval
    immutable
    strict
    language sql
as
$$
select pg_catalog.interval_in(pg_catalog.bpcharout($1), 0::Oid, -1)
$$;

alter function to_interval(char) owner to omm;

