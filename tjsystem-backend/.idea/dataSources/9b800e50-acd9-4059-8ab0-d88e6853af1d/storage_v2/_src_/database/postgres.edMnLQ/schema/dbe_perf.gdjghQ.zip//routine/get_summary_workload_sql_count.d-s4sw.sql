create function get_summary_workload_sql_count(OUT node_name name, OUT workload name, OUT select_count bigint, OUT update_count bigint, OUT insert_count bigint, OUT delete_count bigint, OUT ddl_count bigint, OUT dml_count bigint, OUT dcl_count bigint) returns SETOF record
    language plpgsql
as
$$
DECLARE
  row_data dbe_perf.workload_sql_count%rowtype;
  row_name record;
  query_str text;
  query_str_nodes text;
  BEGIN
    --Get all cn node names
    query_str_nodes := 'select * from dbe_perf.node_name';
    FOR row_name IN EXECUTE(query_str_nodes) LOOP
      query_str := 'SELECT * FROM dbe_perf.workload_sql_count';
      FOR row_data IN EXECUTE(query_str) LOOP
        node_name := row_name.node_name;
        workload := row_data.workload;
        select_count := row_data.select_count;
        update_count := row_data.update_count;
        insert_count := row_data.insert_count;
        delete_count := row_data.delete_count;
        ddl_count := row_data.ddl_count;
        dml_count := row_data.dml_count;
        dcl_count := row_data.dcl_count;
        return next;
      END LOOP;
    END LOOP;
    return;
  END;
$$;

alter function get_summary_workload_sql_count(out name, out name, out bigint, out bigint, out bigint, out bigint, out bigint, out bigint, out bigint) owner to omm;

