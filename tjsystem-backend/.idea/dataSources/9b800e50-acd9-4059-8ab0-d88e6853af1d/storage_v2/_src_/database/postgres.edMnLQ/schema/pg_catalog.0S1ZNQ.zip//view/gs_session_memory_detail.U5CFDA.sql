create view gs_session_memory_detail (sessid, sesstype, contextname, level, parent, totalsize, freesize, usedsize) as
SELECT *
FROM gs_session_memory_detail_tp() gs_session_memory_detail_tp(sessid, sesstype, contextname, level, parent, totalsize,
                                                               freesize, usedsize)
ORDER BY gs_session_memory_detail_tp.sessid;

alter table gs_session_memory_detail
    owner to omm;

