create function date_part(text, reltime) returns double precision
    stable
    strict
    cost 1
    language sql
as
$$
select pg_catalog.date_part($1, cast($2 as pg_catalog.interval))
$$;

alter function date_part(text, reltime) owner to omm;

