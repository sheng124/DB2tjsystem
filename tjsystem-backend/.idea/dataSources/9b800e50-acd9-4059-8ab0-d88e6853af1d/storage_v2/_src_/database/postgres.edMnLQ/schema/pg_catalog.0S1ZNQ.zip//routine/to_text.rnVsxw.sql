create function to_text(real) returns text
    immutable
    strict
    language sql
as
$$
select CAST(pg_catalog.float4out($1) AS VARCHAR)
$$;

alter function to_text(real) owner to omm;

