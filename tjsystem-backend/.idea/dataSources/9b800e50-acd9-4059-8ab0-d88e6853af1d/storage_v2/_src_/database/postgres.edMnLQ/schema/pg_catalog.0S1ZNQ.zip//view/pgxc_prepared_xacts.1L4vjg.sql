create view pgxc_prepared_xacts(pgxc_prepared_xact) as
SELECT DISTINCT *
FROM pgxc_prepared_xact() pgxc_prepared_xact(pgxc_prepared_xact);

alter table pgxc_prepared_xacts
    owner to omm;

