create function get_global_bgwriter_stat(OUT node_name name, OUT checkpoints_timed bigint, OUT checkpoints_req bigint, OUT checkpoint_write_time double precision, OUT checkpoint_sync_time double precision, OUT buffers_checkpoint bigint, OUT buffers_clean bigint, OUT maxwritten_clean bigint, OUT buffers_backend bigint, OUT buffers_backend_fsync bigint, OUT buffers_alloc bigint, OUT stats_reset timestamp with time zone) returns SETOF record
    language plpgsql
as
$$
DECLARE
  row_data dbe_perf.bgwriter_stat%rowtype;
  row_name record;
  query_str text;
  query_str_nodes text;
  BEGIN
    --Get all the node names
    query_str_nodes := 'select * from dbe_perf.node_name';
    FOR row_name IN EXECUTE(query_str_nodes) LOOP
      query_str := 'SELECT * FROM dbe_perf.bgwriter_stat';
      FOR row_data IN EXECUTE(query_str) LOOP
        node_name := row_name.node_name;
        checkpoints_timed := row_data.checkpoints_timed;
        checkpoints_req := row_data.checkpoints_req;
        checkpoint_write_time := row_data.checkpoint_write_time;
        checkpoint_sync_time := row_data.checkpoint_sync_time;
        buffers_checkpoint := row_data.buffers_checkpoint;
        buffers_clean := row_data.buffers_clean;
        maxwritten_clean := row_data.maxwritten_clean;
        buffers_backend := row_data.buffers_backend;
        buffers_backend_fsync := row_data.buffers_backend_fsync;
        buffers_alloc := row_data.buffers_alloc;
        stats_reset := row_data.stats_reset;
        return next;
      END LOOP;
    END LOOP;
    return;
  END;
$$;

alter function get_global_bgwriter_stat(out name, out bigint, out bigint, out double precision, out double precision, out bigint, out bigint, out bigint, out bigint, out bigint, out bigint, out timestamp with time zone) owner to omm;

