create function to_text(interval) returns text
    immutable
    strict
    language sql
as
$$
select CAST(pg_catalog.interval_out($1) AS TEXT)
$$;

alter function to_text(interval) owner to omm;

