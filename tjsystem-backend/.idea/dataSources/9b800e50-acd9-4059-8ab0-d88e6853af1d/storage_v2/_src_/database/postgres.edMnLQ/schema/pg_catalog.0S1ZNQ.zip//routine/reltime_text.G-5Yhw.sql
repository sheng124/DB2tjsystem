create function reltime_text(reltime) returns text
    immutable
    strict
    language sql
as
$$
SELECT CAST(pg_catalog.reltimeout($1) AS text)
$$;

alter function reltime_text(reltime) owner to omm;

