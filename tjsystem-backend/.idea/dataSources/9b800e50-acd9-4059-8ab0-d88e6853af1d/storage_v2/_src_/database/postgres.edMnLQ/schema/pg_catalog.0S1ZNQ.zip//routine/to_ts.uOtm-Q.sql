create function to_ts(character) returns timestamp without time zone
    immutable
    strict
    language sql
as
$$
select pg_catalog.timestamp_in(pg_catalog.bpcharout($1), 0::Oid, -1)
$$;

alter function to_ts(char) owner to omm;

