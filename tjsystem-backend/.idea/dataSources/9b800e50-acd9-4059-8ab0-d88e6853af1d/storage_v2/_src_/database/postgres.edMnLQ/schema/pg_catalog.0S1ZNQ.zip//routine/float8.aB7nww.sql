create function float8(text) returns double precision
    immutable
    strict
    language sql
as
$$
select cast(pg_catalog.to_number($1) as float8)
$$;

alter function float8(text) owner to omm;

