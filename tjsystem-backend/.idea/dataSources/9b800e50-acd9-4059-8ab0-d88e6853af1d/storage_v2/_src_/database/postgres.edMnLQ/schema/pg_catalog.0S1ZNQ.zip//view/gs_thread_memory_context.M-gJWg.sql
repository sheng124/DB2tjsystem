create view gs_thread_memory_context
            (threadid, tid, thrdtype, contextname, level, parent, totalsize, freesize, usedsize) as
SELECT *
FROM pv_thread_memory_detail() pv_thread_memory_detail(threadid, tid, thrdtype, contextname, level, parent, totalsize,
                                                       freesize, usedsize);

alter table gs_thread_memory_context
    owner to omm;

