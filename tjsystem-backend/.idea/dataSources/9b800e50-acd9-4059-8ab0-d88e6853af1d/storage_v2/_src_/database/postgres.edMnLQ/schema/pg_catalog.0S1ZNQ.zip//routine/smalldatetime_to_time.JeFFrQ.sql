create function smalldatetime_to_time(smalldatetime) returns time without time zone
    immutable
    strict
    language sql
as
$$
select pg_catalog.time_in(pg_catalog.smalldatetime_out($1), 0::Oid, -1)
$$;

alter function smalldatetime_to_time(smalldatetime) owner to omm;

