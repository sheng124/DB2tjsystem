create view mpp_tables(schemaname, tablename, tableowner, tablespace, pgroup, nodeoids) as
SELECT n.nspname                   AS schemaname,
       c.relname                   AS tablename,
       pg_get_userbyid(c.relowner) AS tableowner,
       t.spcname                   AS tablespace,
       x.pgroup,
       x.nodeoids
FROM pg_class c
         LEFT JOIN pg_namespace n ON n.oid = c.relnamespace
         LEFT JOIN pg_tablespace t ON t.oid = c.reltablespace
         JOIN pgxc_class x ON x.pcrelid = c.oid
WHERE n.nspname <> 'pmk'::name;

alter table mpp_tables
    owner to omm;

