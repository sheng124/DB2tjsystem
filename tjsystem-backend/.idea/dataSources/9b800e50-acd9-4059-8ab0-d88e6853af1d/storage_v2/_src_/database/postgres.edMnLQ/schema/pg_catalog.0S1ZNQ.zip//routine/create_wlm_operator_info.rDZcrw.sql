create function create_wlm_operator_info(flag integer) returns integer
    language plpgsql
as
$$
DECLARE
	query_ec_str text;
    query_plan_str text;
	query_str text;
	record_cnt int;
	BEGIN
		record_cnt := 0;

		query_ec_str := 'SELECT 
							queryid,
							plan_node_id,
							start_time,
							duration,
							tuple_processed,
							min_peak_memory,
							max_peak_memory,
							average_peak_memory,
							ec_status,
							ec_execute_datanode,
							ec_dsn,
							ec_username,
							ec_query,
							ec_libodbc_type
						FROM pg_catalog.pg_stat_get_wlm_ec_operator_info(0) where ec_operator > 0';
		
        query_plan_str := 'SELECT * FROM pg_catalog.gs_stat_get_wlm_plan_operator_info(0)';

		query_str := 'SELECT * FROM pg_catalog.pg_stat_get_wlm_operator_info(1)';
		
		IF flag > 0 THEN
			EXECUTE 'INSERT INTO gs_wlm_ec_operator_info ' || query_ec_str;
            EXECUTE 'INSERT INTO gs_wlm_plan_operator_info ' || query_plan_str;
			EXECUTE 'INSERT INTO gs_wlm_operator_info ' || query_str;
		ELSE
			EXECUTE query_ec_str;
            EXECUTE query_plan_str;
			EXECUTE query_str;
		END IF;
		
		RETURN record_cnt;
	END;
$$;

alter function create_wlm_operator_info(integer) owner to omm;

